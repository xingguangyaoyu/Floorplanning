import math

def validate_layout(rows, outline, catalog):
    errors, seen, good, overlaps = set(), set(), [], []
    width, height = outline
    for row in rows:
        name, x, y, w, h = row
        if name in seen: errors.add('duplicate:' + name)
        seen.add(name)
        if name not in catalog: errors.add('unknown:' + name)
        if not all(isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v) for v in (x,y,w,h)) or w <= 0 or h <= 0:
            errors.add('number:' + name)
            continue
        good.append(row)
        if name in catalog and (w,h) != tuple(catalog[name]): errors.add('shape:' + name)
        if x < 0 or y < 0 or x+w > width or y+h > height: errors.add('outside:' + name)
    for name in catalog:
        if name not in seen: errors.add('missing:' + name)
    for i,(a,x,y,w,h) in enumerate(good):
        for b,X,Y,W,H in good[i+1:]:
            dx = max(0, min(x+w,X+W)-max(x,X))
            dy = max(0, min(y+h,Y+H)-max(y,Y))
            if dx > 0 and dy > 0:
                ids = sorted([a,b])
                errors.add('overlap:' + '/'.join(ids))
                overlaps.append({'ids':ids, 'area':dx*dy})
    overlaps.sort(key=lambda item:(item['ids'], item['area']))
    return {'legal':not errors, 'errors':sorted(errors), 'overlaps':overlaps}

def metrics_report(rows, outline, catalog):
    check = validate_layout(rows, outline, catalog)
    module_area = sum(w*h for w,h in catalog.values())
    outline_area = outline[0]*outline[1]
    bbox = None
    if rows and all(all(isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v) for v in row[1:]) and row[3]>0 and row[4]>0 for row in rows):
        xmin = min(row[1] for row in rows)
        ymin = min(row[2] for row in rows)
        xmax = max(row[1]+row[3] for row in rows)
        ymax = max(row[2]+row[4] for row in rows)
        bbox = {'xmin':xmin,'ymin':ymin,'xmax':xmax,'ymax':ymax,
                'width':xmax-xmin,'height':ymax-ymin,
                'area':(xmax-xmin)*(ymax-ymin)}
    usable = check['legal'] and bbox is not None and bbox['area']>0
    return {'legal':check['legal'],'errors':check['errors'],
            'module_area':module_area,'outline_area':outline_area,'bbox':bbox,
            'outline_density':module_area/outline_area if usable else None,
            'packing_density':module_area/bbox['area'] if usable else None,
            'outline_dead':outline_area-module_area if usable else None,
            'bbox_dead':bbox['area']-module_area if usable else None}

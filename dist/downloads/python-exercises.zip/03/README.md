# Lesson 03

实现完整评价报告 metrics_report(rows, outline, catalog)。已提供Lab2的validate_layout，无需重写。先检查合法性，再计算真实包围盒、两个密度和两种空余；非法布局只留诊断几何，不给有效分数。

Build a complete metrics report on top of the provided Lab2 validator: true extents, explicit denominators and legal-only scores.

Run from this folder:

```
python check.py starter.py
python check.py reference.py
```

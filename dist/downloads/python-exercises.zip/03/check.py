import importlib.util,math,sys
from pathlib import Path
p=Path(sys.argv[1] if len(sys.argv)>1 else "starter.py")
spec=importlib.util.spec_from_file_location("student",p);student=importlib.util.module_from_spec(spec);spec.loader.exec_module(student)
scope=dict(vars(student));scope["math"]=math
def raises_value_error(f):
    try:f()
    except ValueError:return True
    return False
scope["raises_value_error"]=raises_value_error
failed=0
try:
    ok=bool(eval('metrics_report([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'legal\'] is True and metrics_report([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'errors\']==[] and metrics_report([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'bbox\']=={\'xmin\':0,\'ymin\':0,\'xmax\':9,\'ymax\':3,\'width\':9,\'height\':3,\'area\':27}',scope))
    print(("PASS" if ok else "FAIL"),'baseline legal and raw extents')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'baseline legal and raw extents');failed+=1
except Exception as e:
    print("FAIL",'baseline legal and raw extents',str(e));failed+=1
try:
    ok=bool(eval('metrics_report([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'module_area\']==23 and metrics_report([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'outline_area\']==80',scope))
    print(("PASS" if ok else "FAIL"),'catalog area and outline area')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'catalog area and outline area');failed+=1
except Exception as e:
    print("FAIL",'catalog area and outline area',str(e));failed+=1
try:
    ok=bool(eval('abs(metrics_report([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'outline_density\']-23/80)<1e-10',scope))
    print(("PASS" if ok else "FAIL"),'outline density is a ratio')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'outline density is a ratio');failed+=1
except Exception as e:
    print("FAIL",'outline density is a ratio',str(e));failed+=1
try:
    ok=bool(eval('abs(metrics_report([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'packing_density\']-23/27)<1e-10',scope))
    print(("PASS" if ok else "FAIL"),'packing density uses box')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'packing density uses box');failed+=1
except Exception as e:
    print("FAIL",'packing density uses box',str(e));failed+=1
try:
    ok=bool(eval('metrics_report([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'outline_dead\']==57 and metrics_report([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'bbox_dead\']==4',scope))
    print(("PASS" if ok else "FAIL"),'two kinds of dead space')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'two kinds of dead space');failed+=1
except Exception as e:
    print("FAIL",'two kinds of dead space',str(e));failed+=1
try:
    ok=bool(eval('metrics_report([["A",0,0,3,2],["B",4,1,2,3],["C",0,2,2,2],["D",3,0,3,1],["E",2,2,2,2]],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'legal\'] is True and metrics_report([["A",0,0,3,2],["B",4,1,2,3],["C",0,2,2,2],["D",3,0,3,1],["E",2,2,2,2]],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'bbox\'][\'area\']==24 and metrics_report([["A",0,0,3,2],["B",4,1,2,3],["C",0,2,2,2],["D",3,0,3,1],["E",2,2,2,2]],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'bbox_dead\']==1',scope))
    print(("PASS" if ok else "FAIL"),'compact is the full hard-module witness')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'compact is the full hard-module witness');failed+=1
except Exception as e:
    print("FAIL",'compact is the full hard-module witness',str(e));failed+=1
try:
    ok=bool(eval('metrics_report([["A",0,0,3,2],["B",4,1,2,3],["C",0,2,2,2],["D",3,0,3,1],["E",2,2,2,2]],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'outline_density\']==metrics_report([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'outline_density\'] and metrics_report([["A",0,0,3,2],["B",4,1,2,3],["C",0,2,2,2],["D",3,0,3,1],["E",2,2,2,2]],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'packing_density\']>metrics_report([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'packing_density\']',scope))
    print(("PASS" if ok else "FAIL"),'compaction changes only variable score')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'compaction changes only variable score');failed+=1
except Exception as e:
    print("FAIL",'compaction changes only variable score',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: r[\'legal\'] is True and r[\'bbox\'][\'width\']==6 and r[\'bbox\'][\'height\']==4 and r[\'bbox\'][\'area\']==24)(metrics_report([["A",3,2,3,2],["B",7,3,2,3],["C",3,4,2,2],["D",6,2,3,1],["E",5,4,2,2]],(12,10),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}))',scope))
    print(("PASS" if ok else "FAIL"),'translation preserves width height area')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'translation preserves width height area');failed+=1
except Exception as e:
    print("FAIL",'translation preserves width height area',str(e));failed+=1
try:
    ok=bool(eval('metrics_report([["A",3,2,3,2],["B",7,3,2,3],["C",3,4,2,2],["D",6,2,3,1],["E",5,4,2,2]],(12,10),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'bbox\'][\'xmin\']==3 and metrics_report([["A",3,2,3,2],["B",7,3,2,3],["C",3,4,2,2],["D",6,2,3,1],["E",5,4,2,2]],(12,10),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'bbox\'][\'ymin\']==2',scope))
    print(("PASS" if ok else "FAIL"),'translation retains actual origins')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'translation retains actual origins');failed+=1
except Exception as e:
    print("FAIL",'translation retains actual origins',str(e));failed+=1
try:
    ok=bool(eval('metrics_report([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]],(12,10),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'bbox\']==metrics_report([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'bbox\'] and abs(metrics_report([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]],(12,10),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'outline_density\']-23/120)<1e-10',scope))
    print(("PASS" if ok else "FAIL"),'outline change does not change box')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'outline change does not change box');failed+=1
except Exception as e:
    print("FAIL",'outline change does not change box',str(e));failed+=1
try:
    ok=bool(eval('abs(metrics_report([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",5,2,2,2]],(11,7),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'outline_density\']-23/77)<1e-10',scope))
    print(("PASS" if ok else "FAIL"),'new outline denominator')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'new outline denominator');failed+=1
except Exception as e:
    print("FAIL",'new outline denominator',str(e));failed+=1
try:
    ok=bool(eval('metrics_report([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",5,2,2,2]],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'bbox\'][\'width\']==7 and metrics_report([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",5,2,2,2]],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'bbox\'][\'area\']==28 and metrics_report([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",5,2,2,2]],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'packing_density\']<metrics_report([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'packing_density\']',scope))
    print(("PASS" if ok else "FAIL"),'narrower can have larger area')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'narrower can have larger area');failed+=1
except Exception as e:
    print("FAIL",'narrower can have larger area',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: r[\'legal\'] is False and \'overlap:C/E\' in r[\'errors\'] and all(r[k] is None for k in [\'outline_density\',\'packing_density\',\'outline_dead\',\'bbox_dead\']))(metrics_report([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",6,0,2,2]],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}))',scope))
    print(("PASS" if ok else "FAIL"),'overlap cannot earn a score')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'overlap cannot earn a score');failed+=1
except Exception as e:
    print("FAIL",'overlap cannot earn a score',str(e));failed+=1
try:
    ok=bool(eval('metrics_report([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",6,0,2,2]],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'bbox\'][\'area\']==24',scope))
    print(("PASS" if ok else "FAIL"),'illegal raw geometry remains diagnostic')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'illegal raw geometry remains diagnostic');failed+=1
except Exception as e:
    print("FAIL",'illegal raw geometry remains diagnostic',str(e));failed+=1
try:
    ok=bool(eval('metrics_report([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]][:-1],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'module_area\']==23 and metrics_report([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]][:-1],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'bbox\'][\'area\']==21 and metrics_report([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]][:-1],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'packing_density\'] is None',scope))
    print(("PASS" if ok else "FAIL"),'missing block keeps expected catalog area')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'missing block keeps expected catalog area');failed+=1
except Exception as e:
    print("FAIL",'missing block keeps expected catalog area',str(e));failed+=1
try:
    ok=bool(eval('all(metrics_report([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]][:-1],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[k] is None for k in [\'outline_density\',\'packing_density\',\'outline_dead\',\'bbox_dead\'])',scope))
    print(("PASS" if ok else "FAIL"),'all illegal score fields withheld')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'all illegal score fields withheld');failed+=1
except Exception as e:
    print("FAIL",'all illegal score fields withheld',str(e));failed+=1
try:
    ok=bool(eval('metrics_report([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]] + [[\'A\',0,5,3,2]],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'legal\'] is False and metrics_report([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]] + [[\'A\',0,5,3,2]],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'outline_density\'] is None',scope))
    print(("PASS" if ok else "FAIL"),'duplicate is not a new packed module')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'duplicate is not a new packed module');failed+=1
except Exception as e:
    print("FAIL",'duplicate is not a new packed module',str(e));failed+=1
try:
    ok=bool(eval('\'shape:A\' in metrics_report([[\'A\',0,0,2,3]]+[["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]][1:],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'errors\'] and metrics_report([[\'A\',0,0,2,3]]+[["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]][1:],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'packing_density\'] is None',scope))
    print(("PASS" if ok else "FAIL"),'fixed shape contract is inherited')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'fixed shape contract is inherited');failed+=1
except Exception as e:
    print("FAIL",'fixed shape contract is inherited',str(e));failed+=1
try:
    ok=bool(eval('metrics_report([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]],(8,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'legal\'] is False and metrics_report([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]],(8,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'packing_density\'] is None',scope))
    print(("PASS" if ok else "FAIL"),'outside is filtered before ranking')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'outside is filtered before ranking');failed+=1
except Exception as e:
    print("FAIL",'outside is filtered before ranking',str(e));failed+=1
try:
    ok=bool(eval('metrics_report([[\'A\',float(\'nan\'),0,3,2]]+[["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]][1:],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'bbox\'] is None',scope))
    print(("PASS" if ok else "FAIL"),'nonfinite gives no bounding box')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'nonfinite gives no bounding box');failed+=1
except Exception as e:
    print("FAIL",'nonfinite gives no bounding box',str(e));failed+=1
try:
    ok=bool(eval('metrics_report([[\'A\',0,0,-3,2]]+[["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]][1:],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'bbox\'] is None',scope))
    print(("PASS" if ok else "FAIL"),'negative dimension gives no bounding box')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'negative dimension gives no bounding box');failed+=1
except Exception as e:
    print("FAIL",'negative dimension gives no bounding box',str(e));failed+=1
try:
    ok=bool(eval('metrics_report([[\'A\',0,0,3,0]]+[["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]][1:],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'bbox\'] is None',scope))
    print(("PASS" if ok else "FAIL"),'zero dimension gives no bounding box')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'zero dimension gives no bounding box');failed+=1
except Exception as e:
    print("FAIL",'zero dimension gives no bounding box',str(e));failed+=1
try:
    ok=bool(eval('metrics_report([],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'legal\'] is False and metrics_report([],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'bbox\'] is None and metrics_report([],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'bbox_dead\'] is None',scope))
    print(("PASS" if ok else "FAIL"),'empty rows have missing errors and no scores')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'empty rows have missing errors and no scores');failed+=1
except Exception as e:
    print("FAIL",'empty rows have missing errors and no scores',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: r[\'legal\'] is True and r[\'module_area\']==12 and r[\'bbox\'][\'area\']==12 and r[\'packing_density\']==1)(metrics_report([["P",0,0,3,2],["Q",0,2,2,2],["R",2,2,1,2]],(4,4),{"P":[3,2],"Q":[2,2],"R":[1,2]}))',scope))
    print(("PASS" if ok else "FAIL"),'arbitrary three-module catalog')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'arbitrary three-module catalog');failed+=1
except Exception as e:
    print("FAIL",'arbitrary three-module catalog',str(e));failed+=1
try:
    ok=bool(eval('metrics_report([["P",0,0,3,2],["Q",3,0,2,2],["R",5,0,1,2]],(4,4),{"P":[3,2],"Q":[2,2],"R":[1,2]})[\'bbox\'][\'area\']==12 and metrics_report([["P",0,0,3,2],["Q",3,0,2,2],["R",5,0,1,2]],(4,4),{"P":[3,2],"Q":[2,2],"R":[1,2]})[\'legal\'] is False',scope))
    print(("PASS" if ok else "FAIL"),'equal area can fail the outline')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'equal area can fail the outline');failed+=1
except Exception as e:
    print("FAIL",'equal area can fail the outline',str(e));failed+=1
try:
    ok=bool(eval("(lambda r: r['legal'] is True and r['bbox']['xmin']==0.5 and r['bbox']['ymin']==1.25 and r['bbox']['area']==5 and r['packing_density']==1)(metrics_report([['P',0.5,1.25,1.5,2],['Q',2,1.25,1,2]],(4,4),{'P':(1.5,2),'Q':(1,2)}))",scope))
    print(("PASS" if ok else "FAIL"),'decimal coordinates are not rounded')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'decimal coordinates are not rounded');failed+=1
except Exception as e:
    print("FAIL",'decimal coordinates are not rounded',str(e));failed+=1
try:
    ok=bool(eval('metrics_report([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]][::-1],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})==metrics_report([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})',scope))
    print(("PASS" if ok else "FAIL"),'row order does not change metrics')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'row order does not change metrics');failed+=1
except Exception as e:
    print("FAIL",'row order does not change metrics',str(e));failed+=1
try:
    ok=bool(eval('(lambda rows: (lambda before: (metrics_report(rows,(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}), rows==before)[1])([r[:] for r in rows]))([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]])',scope))
    print(("PASS" if ok else "FAIL"),'input remains unchanged')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'input remains unchanged');failed+=1
except Exception as e:
    print("FAIL",'input remains unchanged',str(e));failed+=1
raise SystemExit(1 if failed else 0)

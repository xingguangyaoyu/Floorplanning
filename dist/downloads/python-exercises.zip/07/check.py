import importlib.util,math,sys
from pathlib import Path
p=Path(sys.argv[1] if len(sys.argv)>1 else "starter.py")
spec=importlib.util.spec_from_file_location("student",p);student=importlib.util.module_from_spec(spec);spec.loader.exec_module(student)
scope=dict(vars(student));scope["math"]=math
def raises_value_error(f):
    try:f()
    except ValueError:return True
    return False
scope["raises_value_error"]=raises_value_error
failed=0
try:
    ok=bool(eval('(lambda a,b: a[\'log\']==b[\'log\'] and a[\'best_energy\']==b[\'best_energy\'])(anneal((\'ABCED\',\'DABCE\'),make_neighbor(constant_rng([0.1,0.2,0.9,0.3]*100)),make_decoder({"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),make_score((10,8)),make_feasible((10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),constant_rng([0.1,0.2,0.9,0.3]*100),cooling(12,0.97),5), anneal((\'ABCED\',\'DABCE\'),make_neighbor(constant_rng([0.1,0.2,0.9,0.3]*100)),make_decoder({"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),make_score((10,8)),make_feasible((10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),constant_rng([0.1,0.2,0.9,0.3]*100),cooling(12,0.97),5))',scope))
    print(("PASS" if ok else "FAIL"),'deterministic: same seed replays the same log')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'deterministic: same seed replays the same log');failed+=1
except Exception as e:
    print("FAIL",'deterministic: same seed replays the same log',str(e));failed+=1
try:
    ok=bool(eval('anneal((\'ABCED\',\'DABCE\'),make_neighbor(constant_rng([0.5]*500)),make_decoder({"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),make_score((10,8)),make_feasible((10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),constant_rng([0.5]*500),cooling(12,0.97),17)[\'evals\']==17',scope))
    print(("PASS" if ok else "FAIL"),'budget is respected exactly')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'budget is respected exactly');failed+=1
except Exception as e:
    print("FAIL",'budget is respected exactly',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: len(r[\'log\'])==6 and all(set(e)>= {\'step\',\'T\',\'candidate_energy\',\'delta\',\'u\',\'accepted\',\'current_energy\',\'best_energy\'} for e in r[\'log\']))(anneal((\'ABCED\',\'DABCE\'),make_neighbor(constant_rng([0.3,0.6,0.9,0.1]*50)),make_decoder({"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),make_score((10,8)),make_feasible((10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),constant_rng([0.3,0.6,0.9,0.1]*50),cooling(12,0.97),6))',scope))
    print(("PASS" if ok else "FAIL"),'log has one complete entry per step')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'log has one complete entry per step');failed+=1
except Exception as e:
    print("FAIL",'log has one complete entry per step',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: [e[\'T\'] for e in r[\'log\'][:3]]==[12.0,12*0.97,12*0.97**2])(anneal((\'ABCED\',\'DABCE\'),make_neighbor(constant_rng([0.5]*300)),make_decoder({"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),make_score((10,8)),make_feasible((10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),constant_rng([0.5]*300),cooling(12,0.97),3))',scope))
    print(("PASS" if ok else "FAIL"),'temperature follows the schedule')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'temperature follows the schedule');failed+=1
except Exception as e:
    print("FAIL",'temperature follows the schedule',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: all(e[\'accepted\'] for e in r[\'log\'] if e[\'delta\']<=0))(anneal((\'ABCED\',\'DABCE\'),make_neighbor(constant_rng([0.2,0.8,0.2,0.8]*100)),make_decoder({"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),make_score((10,8)),make_feasible((10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),constant_rng([0.2,0.8,0.2,0.8]*100),cooling(12,0.97),40))',scope))
    print(("PASS" if ok else "FAIL"),'downhill candidates always accept')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'downhill candidates always accept');failed+=1
except Exception as e:
    print("FAIL",'downhill candidates always accept',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: all((not e[\'accepted\']) or True for e in r[\'log\']) and all(e[\'current_energy\']==r[\'log\'][i-1][\'current_energy\'] for i,e in enumerate(r[\'log\']) if i>0 and not e[\'accepted\']))(anneal((\'ABCED\',\'DABCE\'),make_neighbor(constant_rng([0.9,0.9,0.1,0.1]*100)),make_decoder({"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),make_score((10,8)),make_feasible((10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),constant_rng([0.9,0.9,0.1,0.1]*100),cooling(12,0.97),20))',scope))
    print(("PASS" if ok else "FAIL"),'rejected step leaves current energy unchanged')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'rejected step leaves current energy unchanged');failed+=1
except Exception as e:
    print("FAIL",'rejected step leaves current energy unchanged',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: all(not e[\'accepted\'] and i>0 and e[\'current_energy\']==r[\'log\'][i-1][\'current_energy\'] or e[\'accepted\'] or i==0 for i,e in enumerate(r[\'log\'])))(anneal((\'ABCED\',\'DABCE\'),make_neighbor(constant_rng([0.99,0.99,0.01,0.01]*100)),make_decoder({"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),make_score((10,8)),make_feasible((10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),constant_rng([0.99,0.99,0.01,0.01]*100),cooling(12,0.97),3))',scope))
    print(("PASS" if ok else "FAIL"),'rejected candidates leave current unchanged')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'rejected candidates leave current unchanged');failed+=1
except Exception as e:
    print("FAIL",'rejected candidates leave current unchanged',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: all(b is None or a is None or b>=a for a,b in zip([e[\'best_energy\'] for e in r[\'log\'] if e[\'best_energy\'] is not None],[e[\'best_energy\'] for e in r[\'log\'] if e[\'best_energy\'] is not None][1:])))(anneal((\'ABCED\',\'DABCE\'),make_neighbor(constant_rng([0.4,0.4,0.4,0.4]*200)),make_decoder({"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),make_score((10,8)),make_feasible((10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),constant_rng([0.4,0.4,0.4,0.4]*200),cooling(12,0.97),50))',scope))
    print(("PASS" if ok else "FAIL"),'best legal area never increases')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'best legal area never increases');failed+=1
except Exception as e:
    print("FAIL",'best legal area never increases',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: r[\'best_legal\'] is not None and validate_layout(r[\'best_legal\'],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'legal\'] is True)(anneal((\'ABCED\',\'DABCE\'),make_neighbor(constant_rng([0.6]*400)),make_decoder({"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),make_score((10,8)),make_feasible((10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),constant_rng([0.6]*400),cooling(12,0.97),60))',scope))
    print(("PASS" if ok else "FAIL"),'best legal layout passes the Lab2 checker')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'best legal layout passes the Lab2 checker');failed+=1
except Exception as e:
    print("FAIL",'best legal layout passes the Lab2 checker',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: r[\'final_energy\']>=r[\'best_energy\']-1e-9)(anneal((\'ABCED\',\'DABCE\'),make_neighbor(constant_rng([0.7]*400)),make_decoder({"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),make_score((10,8)),make_feasible((10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),constant_rng([0.7]*400),cooling(12,0.97),80))',scope))
    print(("PASS" if ok else "FAIL"),'final may be worse than best')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'final may be worse than best');failed+=1
except Exception as e:
    print("FAIL",'final may be worse than best',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: r[\'accepted\']==sum(1 for e in r[\'log\'] if e[\'accepted\']))(anneal((\'ABCED\',\'DABCE\'),make_neighbor(constant_rng([0.5]*300)),make_decoder({"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),make_score((10,8)),make_feasible((10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),constant_rng([0.5]*300),cooling(12,0.97),25))',scope))
    print(("PASS" if ok else "FAIL"),'accepted counter matches the log')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'accepted counter matches the log');failed+=1
except Exception as e:
    print("FAIL",'accepted counter matches the log',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: all((not e[\'accepted\']) or e[\'delta\']<=0 or e[\'u\']<pow(2.718281828459045,-e[\'delta\']/e[\'T\'])+1e-9 for e in r[\'log\']))(anneal((\'ABCED\',\'DABCE\'),make_neighbor(constant_rng([0.05,0.95,0.15,0.85]*100)),make_decoder({"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),make_score((10,8)),make_feasible((10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),constant_rng([0.05,0.95,0.15,0.85]*100),cooling(12,0.97),50))',scope))
    print(("PASS" if ok else "FAIL"),'uphill acceptance is bounded by probability')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'uphill acceptance is bounded by probability');failed+=1
except Exception as e:
    print("FAIL",'uphill acceptance is bounded by probability',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: r[\'accepted\']>=0)(anneal((\'ABCED\',\'DABCE\'),make_neighbor(constant_rng([0.99]*400)),make_decoder({"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),make_score((10,8)),make_feasible((10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),constant_rng([0.99]*400),cooling(0.5,1.0),20))',scope))
    print(("PASS" if ok else "FAIL"),'low temperature accepts almost no uphill')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'low temperature accepts almost no uphill');failed+=1
except Exception as e:
    print("FAIL",'low temperature accepts almost no uphill',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: r[\'best_energy\'] is None or r[\'best_energy\']<=r[\'final_energy\']+1e-9)(anneal((\'ABCED\',\'DABCE\'),make_neighbor(constant_rng([0.9]*300)),make_decoder({"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),make_score((10,8)),make_feasible((10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),constant_rng([0.9]*300),cooling(12,0.97),5))',scope))
    print(("PASS" if ok else "FAIL"),'best energy never exceeds final energy')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'best energy never exceeds final energy');failed+=1
except Exception as e:
    print("FAIL",'best energy never exceeds final energy',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: r[\'evals\']>0)(anneal((\'ABCED\',\'DABCE\'),make_neighbor(constant_rng([0.3]*300)),make_decoder({"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),make_score((10,8)),make_feasible((10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),constant_rng([0.3]*300),cooling(12,0.97),3))',scope))
    print(("PASS" if ok else "FAIL"),'inputs are not mutated by neighbor')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'inputs are not mutated by neighbor');failed+=1
except Exception as e:
    print("FAIL",'inputs are not mutated by neighbor',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: r[\'best_legal\'] is None and r[\'best_energy\'] is None)(anneal((\'ABCED\',\'DABCE\'),make_neighbor(constant_rng([0.5]*100)),lambda x: [[\'A\',0,0,3,2],[\'B\',3,0,2,3],[\'C\',5,0,2,2],[\'D\',0,2,3,1]],make_score((10,8)),make_feasible((10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),constant_rng([0.5]*100),cooling(12,0.97),2))',scope))
    print(("PASS" if ok else "FAIL"),'no legal layout yields explicit None')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'no legal layout yields explicit None');failed+=1
except Exception as e:
    print("FAIL",'no legal layout yields explicit None',str(e));failed+=1
try:
    ok=bool(eval('anneal((\'ABCED\',\'DABCE\'),make_neighbor(constant_rng([0.5]*10)),make_decoder({"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),make_score((10,8)),make_feasible((10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),constant_rng([0.5]*10),cooling(12,0.97),1)[\'evals\']==1',scope))
    print(("PASS" if ok else "FAIL"),'budget one evaluates exactly once')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'budget one evaluates exactly once');failed+=1
except Exception as e:
    print("FAIL",'budget one evaluates exactly once',str(e));failed+=1
try:
    ok=bool(eval('(lambda r, s: abs(r[\'log\'][0][\'candidate_energy\']-s(decode_sequence_pair(\'BACED\',\'DABCE\',{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'rows\']))<1e-6)(anneal((\'ABCED\',\'DABCE\'),make_neighbor(constant_rng([0.1]*20)),make_decoder({"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),make_score((10,8)),make_feasible((10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),constant_rng([0.1]*20),cooling(12,0.97),1), make_score((10,8)))',scope))
    print(("PASS" if ok else "FAIL"),'candidate energy equals score of the decoded neighbor')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'candidate energy equals score of the decoded neighbor');failed+=1
except Exception as e:
    print("FAIL",'candidate energy equals score of the decoded neighbor',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: r[\'log\'][0][\'T\']==12.0 and r[\'log\'][1][\'T\']==12*0.97)(anneal((\'ABCED\',\'DABCE\'),make_neighbor(constant_rng([0.5]*20)),make_decoder({"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),make_score((10,8)),make_feasible((10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),constant_rng([0.5]*20),cooling(12,0.97),2))',scope))
    print(("PASS" if ok else "FAIL"),'schedule is called with zero-based step')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'schedule is called with zero-based step');failed+=1
except Exception as e:
    print("FAIL",'schedule is called with zero-based step',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: r[\'best_legal\'] is None or all(a is not b for a,b in zip(r[\'best_legal\'],r[\'final\'])) or r[\'best_legal\'][0] is not r[\'final\'][0])(anneal((\'ABCED\',\'DABCE\'),make_neighbor(constant_rng([0.6]*50)),make_decoder({"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),make_score((10,8)),make_feasible((10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),constant_rng([0.6]*50),cooling(12,0.97),5))',scope))
    print(("PASS" if ok else "FAIL"),'best is a copy, not the same list object')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'best is a copy, not the same list object');failed+=1
except Exception as e:
    print("FAIL",'best is a copy, not the same list object',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: all(e[\'T\']==5.0 for e in r[\'log\']))(anneal((\'ABCED\',\'DABCE\'),make_neighbor(constant_rng([0.5]*30)),make_decoder({"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),make_score((10,8)),make_feasible((10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),constant_rng([0.5]*30),lambda k: 5.0,4))',scope))
    print(("PASS" if ok else "FAIL"),'constant temperature schedule is honored')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'constant temperature schedule is honored');failed+=1
except Exception as e:
    print("FAIL",'constant temperature schedule is honored',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: r[\'log\'][0][\'delta\'] is not None)(anneal((\'ABCED\',\'DABCE\'),make_neighbor(constant_rng([0.2]*50)),make_decoder({"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),make_score((10,8)),make_feasible((10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),constant_rng([0.2]*50),cooling(12,0.97),2))',scope))
    print(("PASS" if ok else "FAIL"),'neighbors differ from the current encoding')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'neighbors differ from the current encoding');failed+=1
except Exception as e:
    print("FAIL",'neighbors differ from the current encoding',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: any(e[\'delta\']>0 and e[\'accepted\'] for e in r[\'log\']) and any(e[\'delta\']<0 for e in r[\'log\']))(anneal((\'ABCED\',\'DABCE\'),make_neighbor(constant_rng([0.1,0.3,0.9,0.2,0.1,0.3,0.9,0.2]*100)),make_decoder({"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),make_score((10,8)),make_feasible((10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),constant_rng([0.1,0.3,0.9,0.2,0.1,0.3,0.9,0.2]*100),cooling(12,0.97),30))',scope))
    print(("PASS" if ok else "FAIL"),'uphill then downhill both handled in one log')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'uphill then downhill both handled in one log');failed+=1
except Exception as e:
    print("FAIL",'uphill then downhill both handled in one log',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: sorted(x[0] for x in r[\'final\'])==[\'A\',\'B\',\'C\',\'D\',\'E\'])(anneal((\'ABCED\',\'DABCE\'),make_neighbor(constant_rng([0.8]*30)),make_decoder({"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),make_score((10,8)),make_feasible((10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}),constant_rng([0.8]*30),cooling(12,0.97),3))',scope))
    print(("PASS" if ok else "FAIL"),'returned final is the decoded rows')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'returned final is the decoded rows');failed+=1
except Exception as e:
    print("FAIL",'returned final is the decoded rows',str(e));failed+=1
raise SystemExit(1 if failed else 0)

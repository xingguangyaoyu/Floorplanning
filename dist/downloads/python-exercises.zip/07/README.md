# Lesson 07

实现通用退火状态机 anneal(initial, neighbor, decode, score, feasible, rng, schedule, budget)：当前/候选/最好合法解分开保存；ΔE≤0 直接接受，ΔE>0 以 exp(−ΔE/T) 与 u 比较；拒绝不改当前；最好合法解只减不增；日志记录每步 T、候选能量、ΔE、u、接受、当前能量、最好能量；恰好评估 budget 次。已提供 Lab6 解码器、能量/可行/邻居/随机数/温度计划的构造器——状态机是你来实现的部分。

Implement the generic annealing state machine anneal(initial, neighbor, decode, score, feasible, rng, schedule, budget): current/candidate/best-legal are stored separately; accept downhill always and uphill when u < exp(-delta/T); a rejected candidate must not touch current; the best legal solution only improves; the log records T, candidate energy, delta, u, acceptance, current and best energy per step; exactly budget evaluations. The Lab6 decoder and score/feasible/neighbor/rng/schedule builders are provided - the state machine is yours.

Run from this folder:

```
python check.py starter.py
python check.py reference.py
```

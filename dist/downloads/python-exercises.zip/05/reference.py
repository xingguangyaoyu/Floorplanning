import math

def validate_layout(rows, outline, catalog):
    errors, seen, good, overlaps = set(), set(), [], []
    width, height = outline
    for row in rows:
        name, x, y, w, h = row
        if name in seen: errors.add('duplicate:' + name)
        seen.add(name)
        if name not in catalog: errors.add('unknown:' + name)
        if not all(isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v) for v in (x,y,w,h)) or w <= 0 or h <= 0:
            errors.add('number:' + name)
            continue
        good.append(row)
        if name in catalog and (w,h) != tuple(catalog[name]): errors.add('shape:' + name)
        if x < 0 or y < 0 or x+w > width or y+h > height: errors.add('outside:' + name)
    for name in catalog:
        if name not in seen: errors.add('missing:' + name)
    for i,(a,x,y,w,h) in enumerate(good):
        for b,X,Y,W,H in good[i+1:]:
            dx = max(0, min(x+w,X+W)-max(x,X))
            dy = max(0, min(y+h,Y+H)-max(y,Y))
            if dx > 0 and dy > 0:
                ids = sorted([a,b])
                errors.add('overlap:' + '/'.join(ids))
                overlaps.append({'ids':ids, 'area':dx*dy})
    overlaps.sort(key=lambda item:(item['ids'], item['area']))
    return {'legal':not errors, 'errors':sorted(errors), 'overlaps':overlaps}

def pack_bstar(tree, modules):
    # Normalize: a bare string counts as a leaf node.
    def node_id(n):
        return n if isinstance(n, str) else n[0]
    def child(n, i):
        return None if isinstance(n, str) else n[i]
    seen = set()
    order = []
    def collect(n):
        if n is None: return
        nid = node_id(n)
        if nid in seen:
            raise ValueError(f'duplicate:{nid}')
        if nid not in modules:
            raise ValueError(f'unknown:{nid}')
        seen.add(nid); order.append(nid)
        collect(child(n, 1)); collect(child(n, 2))
    try:
        collect(tree)
    except ValueError as e:
        return {'ok': False, 'errors': [str(e)], 'order': [], 'coords': None,
                'rows': [], 'contour': None, 'trace': []}
    missing = [i for i in modules if i not in seen]
    if missing:
        return {'ok': False, 'errors': ['missing:' + ','.join(missing)], 'order': [],
                'coords': None, 'rows': [], 'contour': None, 'trace': []}

    contour = []          # (x1, x2, height), sorted by x1, equal neighbours merged
    coords = {}
    trace = []

    def place(nid, x, parent_top):
        w, h = modules[nid]
        # Query the WHOLE footprint [x, x+w); the max is the landing height.
        y = max([0] + [seg_h for (x1, x2, seg_h) in contour if x2 > x and x1 < x + w])
        coords[nid] = (x, y, w, h)
        kept = []
        for (x1, x2, seg_h) in contour:
            if x2 <= x or x1 >= x + w:
                kept.append((x1, x2, seg_h)); continue
            if x1 < x: kept.append((x1, x, seg_h))          # keep left residual
            if x2 > x + w: kept.append((x + w, x2, seg_h))  # keep right residual
        kept.append((x, x + w, y + h))
        kept.sort()
        merged = []
        for seg in kept:
            if merged and merged[-1][1] == seg[0] and merged[-1][2] == seg[2]:
                merged[-1] = (merged[-1][0], seg[1], seg[2])  # merge equal neighbours
            else:
                merged.append(seg)
        contour[:] = merged
        trace.append({'id': nid, 'x': x, 'y': y, 'parent_top': parent_top,
                      'contour': list(contour)})

    def walk(n, x, parent_top):
        if n is None: return
        nid = node_id(n)
        place(nid, x, parent_top)
        pw, ph = modules[nid]
        walk(child(n, 1), x + pw, coords[nid][1] + ph)   # left child: parent's right edge
        walk(child(n, 2), x, coords[nid][1] + ph)        # right child: parent's x

    walk(tree, 0, 0)
    rows = [[i, *coords[i]] for i in sorted(coords)]
    return {'ok': True, 'errors': [], 'order': order, 'coords': coords, 'rows': rows,
            'contour': list(contour), 'trace': trace}

# Lesson 05

实现完整打包器 pack_bstar(tree, modules)：先序遍历树，左孩子从父块右边缘开始、右孩子与父块同 x；每个模块落到整个覆盖区间 [x,x+w) 下最高的轮廓线上。放块后拆分旧区间、保留两侧残段、合并相邻等高段。返回 order/coords/rows/contour/trace。错误码：unknown:X、duplicate:X、missing:清单。tree 是 (id, left, right) 嵌套元组，叶子可写 (id,None,None) 或直接写 id 字符串。

Implement the full packer pack_bstar(tree, modules): preorder walk, left child at the parent right edge, right child at the parent x; each block lands on the highest skyline under its whole footprint [x,x+w). Split old segments, keep residuals, merge equal neighbours. Return order/coords/rows/contour/trace. Error codes: unknown:X, duplicate:X, missing:list. tree is nested (id,left,right) tuples; leaves may be (id,None,None) or the bare id string.

Run from this folder:

```
python check.py starter.py
python check.py reference.py
```

import importlib.util,math,sys
from pathlib import Path
p=Path(sys.argv[1] if len(sys.argv)>1 else "starter.py")
spec=importlib.util.spec_from_file_location("student",p);student=importlib.util.module_from_spec(spec);spec.loader.exec_module(student)
scope=dict(vars(student));scope["math"]=math
def raises_value_error(f):
    try:f()
    except ValueError:return True
    return False
scope["raises_value_error"]=raises_value_error
failed=0
try:
    ok=bool(eval('pack_bstar((\'A\',(\'B\',(\'C\',(\'E\',None,None),None),None),(\'D\',None,None)),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'order\']==[\'A\',\'B\',\'C\',\'E\',\'D\']',scope))
    print(("PASS" if ok else "FAIL"),'golden tree walks in preorder')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'golden tree walks in preorder');failed+=1
except Exception as e:
    print("FAIL",'golden tree walks in preorder',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: r[\'coords\'][\'A\']==(0,0,3,2) and r[\'coords\'][\'B\']==(3,0,2,3) and r[\'coords\'][\'C\']==(5,0,2,2) and r[\'coords\'][\'E\']==(7,0,2,2) and r[\'coords\'][\'D\']==(0,2,3,1))(pack_bstar((\'A\',(\'B\',(\'C\',(\'E\',None,None),None),None),(\'D\',None,None)),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}))',scope))
    print(("PASS" if ok else "FAIL"),'golden coordinates match the taught layout')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'golden coordinates match the taught layout');failed+=1
except Exception as e:
    print("FAIL",'golden coordinates match the taught layout',str(e));failed+=1
try:
    ok=bool(eval('validate_layout(pack_bstar((\'A\',(\'B\',(\'C\',(\'E\',None,None),None),None),(\'D\',None,None)),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'rows\'],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'legal\'] is True',scope))
    print(("PASS" if ok else "FAIL"),'golden rows pass the Lab2 checker')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'golden rows pass the Lab2 checker');failed+=1
except Exception as e:
    print("FAIL",'golden rows pass the Lab2 checker',str(e));failed+=1
try:
    ok=bool(eval('pack_bstar((\'A\',(\'B\',(\'C\',(\'E\',None,None),None),None),(\'D\',None,None)),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'contour\']==[(0,5,3),(5,9,2)]',scope))
    print(("PASS" if ok else "FAIL"),'final contour merges equal neighbours')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'final contour merges equal neighbours');failed+=1
except Exception as e:
    print("FAIL",'final contour merges equal neighbours',str(e));failed+=1
try:
    ok=bool(eval('pack_bstar((\'A\',(\'B\',(\'C\',(\'E\',None,None),None),None),(\'D\',None,None)),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'trace\'][4][\'y\']==2 and pack_bstar((\'A\',(\'B\',(\'C\',(\'E\',None,None),None),None),(\'D\',None,None)),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'trace\'][4][\'contour\']==[(0,5,3),(5,9,2)]',scope))
    print(("PASS" if ok else "FAIL"),'D rests on the highest segment under its footprint')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'D rests on the highest segment under its footprint');failed+=1
except Exception as e:
    print("FAIL",'D rests on the highest segment under its footprint',str(e));failed+=1
try:
    ok=bool(eval('pack_bstar((\'A\',(\'B\',(\'C\',(\'E\',None,None),None),None),(\'D\',None,None)),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'coords\'][\'B\'][0]==pack_bstar((\'A\',(\'B\',(\'C\',(\'E\',None,None),None),None),(\'D\',None,None)),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'coords\'][\'A\'][0]+3',scope))
    print(("PASS" if ok else "FAIL"),'left child starts at the parent right edge')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'left child starts at the parent right edge');failed+=1
except Exception as e:
    print("FAIL",'left child starts at the parent right edge',str(e));failed+=1
try:
    ok=bool(eval('pack_bstar((\'A\',(\'B\',(\'C\',(\'E\',None,None),None),None),(\'D\',None,None)),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'coords\'][\'D\'][0]==pack_bstar((\'A\',(\'B\',(\'C\',(\'E\',None,None),None),None),(\'D\',None,None)),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'coords\'][\'A\'][0] and pack_bstar((\'C\',(\'B\',(\'A\',(\'E\',None,None),None),None),(\'D\',None,None)),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'coords\'][\'D\'][0]==pack_bstar((\'C\',(\'B\',(\'A\',(\'E\',None,None),None),None),(\'D\',None,None)),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'coords\'][\'C\'][0]',scope))
    print(("PASS" if ok else "FAIL"),'right child shares the parent x')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'right child shares the parent x');failed+=1
except Exception as e:
    print("FAIL",'right child shares the parent x',str(e));failed+=1
try:
    ok=bool(eval('pack_bstar((\'C\',(\'B\',(\'A\',(\'E\',None,None),None),None),(\'D\',None,None)),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'coords\'][\'D\'][1]==3 and pack_bstar((\'C\',(\'B\',(\'A\',(\'E\',None,None),None),None),(\'D\',None,None)),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'trace\'][4][\'parent_top\']==2',scope))
    print(("PASS" if ok else "FAIL"),'right child is not always on the parent top')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'right child is not always on the parent top');failed+=1
except Exception as e:
    print("FAIL",'right child is not always on the parent top',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: r[\'coords\'][\'C\']==(0,0,2,2) and r[\'coords\'][\'B\']==(2,0,2,3) and r[\'coords\'][\'A\']==(4,0,3,2) and validate_layout(r[\'rows\'],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'legal\'] is True)(pack_bstar((\'C\',(\'B\',(\'A\',(\'E\',None,None),None),None),(\'D\',None,None)),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}))',scope))
    print(("PASS" if ok else "FAIL"),'lift tree boxes 9x4')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'lift tree boxes 9x4');failed+=1
except Exception as e:
    print("FAIL",'lift tree boxes 9x4',str(e));failed+=1
try:
    ok=bool(eval('pack_bstar((\'A\',(\'D\',None,(\'C\',(\'B\',(\'E\',None,None),None),None)),None),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'coords\'][\'B\']==(5,1,2,3) and pack_bstar((\'A\',(\'D\',None,(\'C\',(\'B\',(\'E\',None,None),None),None)),None),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'coords\'][\'C\']==(3,1,2,2)',scope))
    print(("PASS" if ok else "FAIL"),'residual segment lifts the next block')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'residual segment lifts the next block');failed+=1
except Exception as e:
    print("FAIL",'residual segment lifts the next block',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: validate_layout(r[\'rows\'],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'legal\'] is True and (5,6,1) not in r[\'contour\'] and (0,3,2) in r[\'contour\'])(pack_bstar((\'A\',(\'D\',None,(\'C\',(\'B\',(\'E\',None,None),None),None)),None),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}))',scope))
    print(("PASS" if ok else "FAIL"),'residual tree stays legal and keeps D segment')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'residual tree stays legal and keeps D segment');failed+=1
except Exception as e:
    print("FAIL",'residual tree stays legal and keeps D segment',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: r[\'coords\'][\'D\']==(5,2,3,1) and r[\'order\']==[\'A\',\'B\',\'C\',\'E\',\'D\'])(pack_bstar((\'A\',(\'B\',(\'C\',(\'E\',None,None),(\'D\',None,None)),None),None),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}))',scope))
    print(("PASS" if ok else "FAIL"),'moving D to the right child of C')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'moving D to the right child of C');failed+=1
except Exception as e:
    print("FAIL",'moving D to the right child of C',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: validate_layout(r[\'rows\'],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'legal\'] is True and max(x+w for i,x,y,w,h in r[\'rows\'])*max(y+h for i,x,y,w,h in r[\'rows\'])==27)(pack_bstar((\'A\',(\'B\',(\'C\',(\'E\',None,None),(\'D\',None,None)),None),None),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}))',scope))
    print(("PASS" if ok else "FAIL"),'edit tree keeps bbox 27')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'edit tree keeps bbox 27');failed+=1
except Exception as e:
    print("FAIL",'edit tree keeps bbox 27',str(e));failed+=1
try:
    ok=bool(eval("pack_bstar('P',{'P':(3,2)})['ok'] is True and pack_bstar('P',{'P':(3,2)})['coords']['P']==(0,0,3,2)",scope))
    print(("PASS" if ok else "FAIL"),'bare string leaf is accepted')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'bare string leaf is accepted');failed+=1
except Exception as e:
    print("FAIL",'bare string leaf is accepted',str(e));failed+=1
try:
    ok=bool(eval('pack_bstar((\'C\',(\'B\',(\'A\',(\'E\',None,None),None),None),(\'D\',None,None)),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'rows\']==[[\'A\',4,0,3,2],[\'B\',2,0,2,3],[\'C\',0,0,2,2],[\'D\',0,3,3,1],[\'E\',7,0,2,2]]',scope))
    print(("PASS" if ok else "FAIL"),'lift rows reflect the swapped names')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'lift rows reflect the swapped names');failed+=1
except Exception as e:
    print("FAIL",'lift rows reflect the swapped names',str(e));failed+=1
try:
    ok=bool(eval('\'unknown:F\' in pack_bstar((\'F\',None,None),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'errors\']',scope))
    print(("PASS" if ok else "FAIL"),'unknown module is rejected before packing')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'unknown module is rejected before packing');failed+=1
except Exception as e:
    print("FAIL",'unknown module is rejected before packing',str(e));failed+=1
try:
    ok=bool(eval('\'duplicate:A\' in pack_bstar((\'A\',(\'A\',None,None),None),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'errors\']',scope))
    print(("PASS" if ok else "FAIL"),'duplicate module is rejected')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'duplicate module is rejected');failed+=1
except Exception as e:
    print("FAIL",'duplicate module is rejected',str(e));failed+=1
try:
    ok=bool(eval('pack_bstar((\'A\',None,None),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'errors\'][0].startswith(\'missing:\')',scope))
    print(("PASS" if ok else "FAIL"),'missing module is rejected')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'missing module is rejected');failed+=1
except Exception as e:
    print("FAIL",'missing module is rejected',str(e));failed+=1
try:
    ok=bool(eval('pack_bstar((42,None,None),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'ok\'] is False',scope))
    print(("PASS" if ok else "FAIL"),'wrong shape tree is rejected as unknown')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'wrong shape tree is rejected as unknown');failed+=1
except Exception as e:
    print("FAIL",'wrong shape tree is rejected as unknown',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: len(r[\'trace\'])==5 and r[\'trace\'][0][\'contour\']==[(0,3,2)] and r[\'trace\'][-1][\'contour\']==r[\'contour\'])(pack_bstar((\'A\',(\'B\',(\'C\',(\'E\',None,None),None),None),(\'D\',None,None)),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}))',scope))
    print(("PASS" if ok else "FAIL"),'trace has one entry per placement with contour snapshots')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'trace has one entry per placement with contour snapshots');failed+=1
except Exception as e:
    print("FAIL",'trace has one entry per placement with contour snapshots',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: r[\'coords\'][\'E\']==(0,2,2,2) and validate_layout(r[\'rows\'],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'legal\'] is True)(pack_bstar((\'A\',(\'B\',(\'C\',(\'D\',None,None),None),None),(\'E\',None,None)),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}))',scope))
    print(("PASS" if ok else "FAIL"),'bad tree decodes legally to 10x4')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'bad tree decodes legally to 10x4');failed+=1
except Exception as e:
    print("FAIL",'bad tree decodes legally to 10x4',str(e));failed+=1
try:
    ok=bool(eval("pack_bstar(('P',None,None),{'P':(1.5,2)})['coords']['P']==(0,0,1.5,2)",scope))
    print(("PASS" if ok else "FAIL"),'decimal modules keep precision')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'decimal modules keep precision');failed+=1
except Exception as e:
    print("FAIL",'decimal modules keep precision',str(e));failed+=1
try:
    ok=bool(eval('(lambda t: (pack_bstar(t,{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}), t==(\'A\',(\'B\',(\'C\',(\'E\',None,None),None),None),(\'D\',None,None)))[1])(((\'A\'),(\'B\'),(\'C\'),(\'E\'),(\'D\')) if False else (\'A\',(\'B\',(\'C\',(\'E\',None,None),None),None),(\'D\',None,None)))',scope))
    print(("PASS" if ok else "FAIL"),'input tree is not mutated')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'input tree is not mutated');failed+=1
except Exception as e:
    print("FAIL",'input tree is not mutated',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: all(0<=v[0] and v[0]+v[2]<=10 for v in r[\'coords\'].values()))(pack_bstar((\'A\',(\'B\',(\'C\',(\'E\',None,None),None),None),(\'D\',None,None)),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}))',scope))
    print(("PASS" if ok else "FAIL"),'every placement is non-overlapping by construction')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'every placement is non-overlapping by construction');failed+=1
except Exception as e:
    print("FAIL",'every placement is non-overlapping by construction',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: r[\'ok\'] is True and validate_layout(r[\'rows\'],(8,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'legal\'] is False)(pack_bstar((\'A\',(\'B\',(\'C\',(\'E\',None,None),None),None),(\'D\',None,None)),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}))',scope))
    print(("PASS" if ok else "FAIL"),'tree legality does not mean outline fit')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'tree legality does not mean outline fit');failed+=1
except Exception as e:
    print("FAIL",'tree legality does not mean outline fit',str(e));failed+=1
raise SystemExit(1 if failed else 0)

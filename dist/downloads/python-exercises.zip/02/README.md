# Lesson 02

实现完整布局检查器 validate_layout(rows, outline, catalog)。rows每项为(id,x,y,w,h)，outline为(宽,高)，catalog把名称映射到固定(宽,高)。返回legal、排序去重errors和带真实交叠面积的overlaps；共边和共角允许，禁止旋转。

Implement a complete hard-module layout validator. Check identity, finite positive dimensions, fixed shapes, containment and every module pair; report all errors and actual intersection areas.

Run from this folder:

```
python check.py starter.py
python check.py reference.py
```

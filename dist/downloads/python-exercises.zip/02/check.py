import importlib.util,math,sys
from pathlib import Path
p=Path(sys.argv[1] if len(sys.argv)>1 else "starter.py")
spec=importlib.util.spec_from_file_location("student",p);student=importlib.util.module_from_spec(spec);spec.loader.exec_module(student)
scope=dict(vars(student));scope["math"]=math
def raises_value_error(f):
    try:f()
    except ValueError:return True
    return False
scope["raises_value_error"]=raises_value_error
failed=0
try:
    ok=bool(eval('validate_layout([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]], (10,8), {"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}) == {\'legal\': True, \'errors\': [], \'overlaps\': []}',scope))
    print(("PASS" if ok else "FAIL"),'all five with shared edges')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'all five with shared edges');failed+=1
except Exception as e:
    print("FAIL",'all five with shared edges',str(e));failed+=1
try:
    ok=bool(eval('validate_layout([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2], ["F",0,0,1,1]], (10,8), {"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'legal\'] is False',scope))
    print(("PASS" if ok else "FAIL"),'positive overlap illegal')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'positive overlap illegal');failed+=1
except Exception as e:
    print("FAIL",'positive overlap illegal',str(e));failed+=1
try:
    ok=bool(eval('\'missing:B\' in validate_layout([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]][:1]+[["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]][2:], (10,8), {"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'errors\']',scope))
    print(("PASS" if ok else "FAIL"),'missing is not a count check')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'missing is not a count check');failed+=1
except Exception as e:
    print("FAIL",'missing is not a count check',str(e));failed+=1
try:
    ok=bool(eval('\'duplicate:A\' in validate_layout([[\'A\',0,0,3,2],[\'A\',3,0,2,3]]+[["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]][2:], (10,8), {"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'errors\'] and \'missing:B\' in validate_layout([[\'A\',0,0,3,2],[\'A\',3,0,2,3]]+[["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]][2:], (10,8), {"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'errors\']',scope))
    print(("PASS" if ok else "FAIL"),'duplicate and missing together')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'duplicate and missing together');failed+=1
except Exception as e:
    print("FAIL",'duplicate and missing together',str(e));failed+=1
try:
    ok=bool(eval('\'unknown:F\' in validate_layout([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]] + [[\'F\',8,6,1,1]], (10,8), {"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'errors\']',scope))
    print(("PASS" if ok else "FAIL"),'unknown name')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'unknown name');failed+=1
except Exception as e:
    print("FAIL",'unknown name',str(e));failed+=1
try:
    ok=bool(eval('\'outside:E\' in validate_layout([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]][:-1]+[[\'E\',9,0,2,2]], (10,8), {"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'errors\']',scope))
    print(("PASS" if ok else "FAIL"),'right boundary')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'right boundary');failed+=1
except Exception as e:
    print("FAIL",'right boundary',str(e));failed+=1
try:
    ok=bool(eval('\'outside:E\' in validate_layout([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]][:-1]+[[\'E\',7,7,2,2]], (10,8), {"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'errors\']',scope))
    print(("PASS" if ok else "FAIL"),'top boundary')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'top boundary');failed+=1
except Exception as e:
    print("FAIL",'top boundary',str(e));failed+=1
try:
    ok=bool(eval('\'outside:A\' in validate_layout([[\'A\',-1,0,3,2]]+[["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]][1:], (10,8), {"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'errors\']',scope))
    print(("PASS" if ok else "FAIL"),'negative origin')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'negative origin');failed+=1
except Exception as e:
    print("FAIL",'negative origin',str(e));failed+=1
try:
    ok=bool(eval('\'shape:A\' in validate_layout([[\'A\',0,0,2,3]]+[["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]][1:], (10,8), {"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'errors\']',scope))
    print(("PASS" if ok else "FAIL"),'hard module rotation disallowed')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'hard module rotation disallowed');failed+=1
except Exception as e:
    print("FAIL",'hard module rotation disallowed',str(e));failed+=1
try:
    ok=bool(eval('\'number:A\' in validate_layout([[\'A\',0,0,3,0]]+[["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]][1:], (10,8), {"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'errors\']',scope))
    print(("PASS" if ok else "FAIL"),'zero height')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'zero height');failed+=1
except Exception as e:
    print("FAIL",'zero height',str(e));failed+=1
try:
    ok=bool(eval('\'number:A\' in validate_layout([[\'A\',0,0,-3,-2]]+[["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]][1:], (10,8), {"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'errors\']',scope))
    print(("PASS" if ok else "FAIL"),'negative dimensions')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'negative dimensions');failed+=1
except Exception as e:
    print("FAIL",'negative dimensions',str(e));failed+=1
try:
    ok=bool(eval('\'number:A\' in validate_layout([[\'A\',float(\'nan\'),0,3,2]]+[["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]][1:], (10,8), {"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'errors\']',scope))
    print(("PASS" if ok else "FAIL"),'nan coordinates')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'nan coordinates');failed+=1
except Exception as e:
    print("FAIL",'nan coordinates',str(e));failed+=1
try:
    ok=bool(eval('\'number:A\' in validate_layout([[\'A\',0,float(\'inf\'),3,2]]+[["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]][1:], (10,8), {"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'errors\']',scope))
    print(("PASS" if ok else "FAIL"),'infinite coordinates')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'infinite coordinates');failed+=1
except Exception as e:
    print("FAIL",'infinite coordinates',str(e));failed+=1
try:
    ok=bool(eval('\'number:A\' in validate_layout([[\'A\',False,0,3,2]]+[["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]][1:], (10,8), {"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'errors\']',scope))
    print(("PASS" if ok else "FAIL"),'booleans are not coordinates')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'booleans are not coordinates');failed+=1
except Exception as e:
    print("FAIL",'booleans are not coordinates',str(e));failed+=1
try:
    ok=bool(eval('\'overlap:C/E\' in validate_layout([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]][:-1]+[[\'E\',6,0,2,2]], (10,8), {"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'errors\']',scope))
    print(("PASS" if ok else "FAIL"),'not only the first pair')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'not only the first pair');failed+=1
except Exception as e:
    print("FAIL",'not only the first pair',str(e));failed+=1
try:
    ok=bool(eval('any(p[\'ids\']==[\'C\',\'E\'] and p[\'area\']==2 for p in validate_layout([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]][:-1]+[[\'E\',6,0,2,2]], (10,8), {"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'overlaps\'])',scope))
    print(("PASS" if ok else "FAIL"),'report actual intersection area')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'report actual intersection area');failed+=1
except Exception as e:
    print("FAIL",'report actual intersection area',str(e));failed+=1
try:
    ok=bool(eval('all(e in validate_layout([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]][:3]+[[\'D\',2,1,3,1],[\'E\',9,1,2,2]], (10,8), {"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'errors\'] for e in [\'overlap:A/D\',\'overlap:B/D\',\'outside:E\'])',scope))
    print(("PASS" if ok else "FAIL"),'multiple conflicts')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'multiple conflicts');failed+=1
except Exception as e:
    print("FAIL",'multiple conflicts',str(e));failed+=1
try:
    ok=bool(eval("validate_layout([['P',3,1,2,6],['Q',1,3,6,2]],(8,8),{'P':(2,6),'Q':(6,2)})['overlaps']==[{'ids':['P','Q'],'area':4}]",scope))
    print(("PASS" if ok else "FAIL"),'cross without contained corners')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'cross without contained corners');failed+=1
except Exception as e:
    print("FAIL",'cross without contained corners',str(e));failed+=1
try:
    ok=bool(eval("validate_layout([['P',0,0,5,5],['Q',1,1,1,1]],(8,8),{'P':(5,5),'Q':(1,1)})['legal'] is False",scope))
    print(("PASS" if ok else "FAIL"),'full containment overlap')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'full containment overlap');failed+=1
except Exception as e:
    print("FAIL",'full containment overlap',str(e));failed+=1
try:
    ok=bool(eval("validate_layout([['P',0,0,2,2],['Q',2,2,2,2]],(4,4),{'P':(2,2),'Q':(2,2)})['legal'] is True",scope))
    print(("PASS" if ok else "FAIL"),'corner contact allowed')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'corner contact allowed');failed+=1
except Exception as e:
    print("FAIL",'corner contact allowed',str(e));failed+=1
try:
    ok=bool(eval("validate_layout([['P',0,0,3,1],['Q',1,2,3,1]],(5,4),{'P':(3,1),'Q':(3,1)})['legal'] is True",scope))
    print(("PASS" if ok else "FAIL"),'x projection alone insufficient')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'x projection alone insufficient');failed+=1
except Exception as e:
    print("FAIL",'x projection alone insufficient',str(e));failed+=1
try:
    ok=bool(eval('\'outside:E\' in validate_layout([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]],(8,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'errors\']',scope))
    print(("PASS" if ok else "FAIL"),'new outline is respected')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'new outline is respected');failed+=1
except Exception as e:
    print("FAIL",'new outline is respected',str(e));failed+=1
try:
    ok=bool(eval("validate_layout([['P',0,0,1,1],['Q',1,0,1,1],['R',2,0,1,1]],(3,1),{'P':(1,1),'Q':(1,1),'R':(1,1)})['legal'] is True",scope))
    print(("PASS" if ok else "FAIL"),'catalog does not assume five modules')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'catalog does not assume five modules');failed+=1
except Exception as e:
    print("FAIL",'catalog does not assume five modules',str(e));failed+=1
try:
    ok=bool(eval('validate_layout([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]] + [[\'F\',0,5,1,1]],(10,8),dict({"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]},F=(1,1)))[\'legal\'] is True',scope))
    print(("PASS" if ok else "FAIL"),'six modules are supported')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'six modules are supported');failed+=1
except Exception as e:
    print("FAIL",'six modules are supported',str(e));failed+=1
try:
    ok=bool(eval('validate_layout([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]][::-1], (10,8), {"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}) == validate_layout([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]], (10,8), {"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})',scope))
    print(("PASS" if ok else "FAIL"),'order does not change report')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'order does not change report');failed+=1
except Exception as e:
    print("FAIL",'order does not change report',str(e));failed+=1
try:
    ok=bool(eval('(lambda rows: (lambda before: (validate_layout(rows,(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}), rows==before)[1])([r[:] for r in rows]))([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]])',scope))
    print(("PASS" if ok else "FAIL"),'input remains unchanged')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'input remains unchanged');failed+=1
except Exception as e:
    print("FAIL",'input remains unchanged',str(e));failed+=1
try:
    ok=bool(eval("validate_layout([['P',0.5,0,1,1],['Q',1.5,0,1,1]],(3,2),{'P':(1,1),'Q':(1,1)})['legal'] is True",scope))
    print(("PASS" if ok else "FAIL"),'decimal edge contact')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'decimal edge contact');failed+=1
except Exception as e:
    print("FAIL",'decimal edge contact',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: r[\'legal\'] is False and r[\'errors\']==sorted(set(r[\'errors\'])))(validate_layout([["A",0,0,3,2],["B",3,0,2,3],["C",5,0,2,2],["D",0,2,3,1],["E",7,0,2,2]][:3]+[[\'D\',2,1,3,1],[\'E\',9,1,2,2]], (10,8), {"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}))',scope))
    print(("PASS" if ok else "FAIL"),'errors sorted with strict illegal flag')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'errors sorted with strict illegal flag');failed+=1
except Exception as e:
    print("FAIL",'errors sorted with strict illegal flag',str(e));failed+=1
raise SystemExit(1 if failed else 0)

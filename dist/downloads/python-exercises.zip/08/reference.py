import math

def audit_layout(rows, integer=True, area=6, low=0.5, high=2):
    expected = {'A': (3,2), 'B': (2,3), 'C': (2,2), 'D': (3,1), 'E': (2,2)}
    errors, seen, valid = set(), set(), []
    for name, x, y, w, h in rows:
        if name in seen: errors.add('duplicate:' + name)
        seen.add(name)
        if name not in expected: errors.add('unknown:' + name)
        numbers = (x,y,w,h)
        if not all(isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v) for v in numbers) or w <= 0 or h <= 0:
            errors.add('number:' + name)
            continue
        valid.append((name,x,y,w,h))
        if integer and not all(float(v).is_integer() for v in numbers): errors.add('grid:' + name)
        if name == 'A':
            if abs(w*h-area) > 1e-8: errors.add('area:A')
            if not low <= w/h <= high: errors.add('aspect:A')
        elif name in expected and (w,h) != expected[name]: errors.add('shape:' + name)
        if x < 0 or y < 0 or x+w > 10+1e-8 or y+h > 8+1e-8: errors.add('outside:' + name)
    for name in expected:
        if name not in seen: errors.add('missing:' + name)
    for i,(a,x,y,w,h) in enumerate(valid):
        for b,X,Y,W,H in valid[i+1:]:
            if x < X+W-1e-9 and X < x+w-1e-9 and y < Y+H-1e-9 and Y < y+h-1e-9:
                errors.add('overlap:' + '/'.join(sorted((a,b))))
    box = None
    if len(valid) == len(rows) and valid:
        box = (max(x+w for _,x,y,w,h in valid)-min(x for _,x,y,w,h in valid)) * (max(y+h for _,x,y,w,h in valid)-min(y for _,x,y,w,h in valid))
    legal = not errors
    return {'legal': legal, 'errors': sorted(errors), 'bbox_area': box,
            'packing_density': (area+17)/box if legal else None,
            'dead_space': box-area-17 if legal else None}

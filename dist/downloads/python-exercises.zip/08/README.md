# Lesson 08

实现完整布局审计器 audit_layout(rows, integer=True, area=6, low=0.5, high=2)。rows每项为(id,x,y,w,h)。检查名称完整/重复/未知、有限正尺寸、A面积与比例、其它固定尺寸且禁旋转、整数网格、10×8包含及全部模块对的正面积重叠。返回legal、排序errors、bbox_area、packing_density、dead_space；非法布局后两项为None。错误码见下方接口说明，面积容差1e−8。

Implement a complete layout auditor: names, finite positive dimensions, shape contracts, integer grid, containment, all-pairs overlap, true bounding box, and legal-only scores. Return the specified report; do not substitute a single shape check.

Run from this folder:

```
python check.py starter.py
python check.py reference.py
```

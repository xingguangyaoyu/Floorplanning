import math

def audit_layout(rows, integer=True, area=6, low=0.5, high=2):
    # rows: [(id, x, y, width, height), ...]
    # errors: sorted strings, e.g. 'missing:E', 'overlap:A/D'.
    # Return {'legal': bool, 'errors': list, 'bbox_area': number_or_None,
    #         'packing_density': number_or_None, 'dead_space': number_or_None}
    # 1. Validate names/numbers and each shape contract.
    # 2. Check containment and every pair (shared edges are allowed).
    # 3. Subtract minima when computing the enclosing box.
    # 4. Only a legal layout has valid density/dead-space scores.
    raise NotImplementedError('Implement the full layout audit')

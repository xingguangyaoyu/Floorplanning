import importlib.util,math,sys
from pathlib import Path
p=Path(sys.argv[1] if len(sys.argv)>1 else "starter.py")
spec=importlib.util.spec_from_file_location("student",p);student=importlib.util.module_from_spec(spec);spec.loader.exec_module(student)
scope=dict(vars(student));scope["math"]=math
def raises_value_error(f):
    try:f()
    except ValueError:return True
    return False
scope["raises_value_error"]=raises_value_error
failed=0
try:
    ok=bool(eval("audit_layout([('A',0,0,3,2),('B',3,0,2,3),('C',5,0,2,2),('D',0,2,3,1),('E',7,0,2,2)])['legal'] is True and audit_layout([('A',0,0,3,2),('B',3,0,2,3),('C',5,0,2,2),('D',0,2,3,1),('E',7,0,2,2)])['errors']==[] and audit_layout([('A',0,0,3,2),('B',3,0,2,3),('C',5,0,2,2),('D',0,2,3,1),('E',7,0,2,2)])['bbox_area']==27",scope))
    print(("PASS" if ok else "FAIL"),'baseline contact')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'baseline contact');failed+=1
except Exception as e:
    print("FAIL",'baseline contact',str(e));failed+=1
try:
    ok=bool(eval("audit_layout([('A',0,0,2,3),('B',2,0,2,3),('C',4,0,2,2),('D',0,3,3,1),('E',4,2,2,2)])['legal'] and audit_layout([('A',0,0,2,3),('B',2,0,2,3),('C',4,0,2,2),('D',0,3,3,1),('E',4,2,2,2)])['bbox_area']==24",scope))
    print(("PASS" if ok else "FAIL"),'compact witness')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'compact witness');failed+=1
except Exception as e:
    print("FAIL",'compact witness',str(e));failed+=1
try:
    ok=bool(eval("abs(audit_layout([('A',0,0,2,3),('B',2,0,2,3),('C',4,0,2,2),('D',0,3,3,1),('E',4,2,2,2)])['packing_density']-23/24)<1e-10 and audit_layout([('A',0,0,2,3),('B',2,0,2,3),('C',4,0,2,2),('D',0,3,3,1),('E',4,2,2,2)])['dead_space']==1",scope))
    print(("PASS" if ok else "FAIL"),'packing denominator')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'packing denominator');failed+=1
except Exception as e:
    print("FAIL",'packing denominator',str(e));failed+=1
try:
    ok=bool(eval("audit_layout([(n,x+2,y+1,w,h) for n,x,y,w,h in [('A',0,0,2,3),('B',2,0,2,3),('C',4,0,2,2),('D',0,3,3,1),('E',4,2,2,2)]])['bbox_area']==24",scope))
    print(("PASS" if ok else "FAIL"),'translated box')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'translated box');failed+=1
except Exception as e:
    print("FAIL",'translated box',str(e));failed+=1
try:
    ok=bool(eval("'overlap:A/D' in audit_layout([('A',0,0,2,3)]+[('A',0,0,3,2),('B',3,0,2,3),('C',5,0,2,2),('D',0,2,3,1),('E',7,0,2,2)][1:])['errors']",scope))
    print(("PASS" if ok else "FAIL"),'all neighbors')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'all neighbors');failed+=1
except Exception as e:
    print("FAIL",'all neighbors',str(e));failed+=1
try:
    ok=bool(eval("'overlap:B/D' in audit_layout([('A',0,0,2,3),('B',3,0,2,3),('C',5,0,2,2),('D',2,2,3,1),('E',7,0,2,2)])['errors']",scope))
    print(("PASS" if ok else "FAIL"),'new conflict')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'new conflict');failed+=1
except Exception as e:
    print("FAIL",'new conflict',str(e));failed+=1
try:
    ok=bool(eval("audit_layout([('A',0,0,2,3)]+[('A',0,0,3,2),('B',3,0,2,3),('C',5,0,2,2),('D',0,2,3,1),('E',7,0,2,2)][1:])['legal'] is False and audit_layout([('A',0,0,2,3)]+[('A',0,0,3,2),('B',3,0,2,3),('C',5,0,2,2),('D',0,2,3,1),('E',7,0,2,2)][1:])['packing_density'] is None and audit_layout([('A',0,0,2,3)]+[('A',0,0,3,2),('B',3,0,2,3),('C',5,0,2,2),('D',0,2,3,1),('E',7,0,2,2)][1:])['dead_space'] is None",scope))
    print(("PASS" if ok else "FAIL"),'invalid scores withheld')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'invalid scores withheld');failed+=1
except Exception as e:
    print("FAIL",'invalid scores withheld',str(e));failed+=1
try:
    ok=bool(eval("audit_layout([('A',0,0,2,3),('B',2,0,2,3),('C',4,0,2,2),('D',0,3,3,1),('E',5.5,1,2,2)],integer=False)['legal'] is False and 'overlap:C/E' in audit_layout([('A',0,0,2,3),('B',2,0,2,3),('C',4,0,2,2),('D',0,3,3,1),('E',5.5,1,2,2)],integer=False)['errors']",scope))
    print(("PASS" if ok else "FAIL"),'non A/B pair overlap')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'non A/B pair overlap');failed+=1
except Exception as e:
    print("FAIL",'non A/B pair overlap',str(e));failed+=1
try:
    ok=bool(eval("'missing:E' in audit_layout([('A',0,0,3,2),('B',3,0,2,3),('C',5,0,2,2),('D',0,2,3,1),('E',7,0,2,2)][:-1])['errors']",scope))
    print(("PASS" if ok else "FAIL"),'missing module')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'missing module');failed+=1
except Exception as e:
    print("FAIL",'missing module',str(e));failed+=1
try:
    ok=bool(eval("'duplicate:A' in audit_layout([('A',0,0,3,2),('B',3,0,2,3),('C',5,0,2,2),('D',0,2,3,1),('E',7,0,2,2)]+[('A',8,6,3,2)])['errors']",scope))
    print(("PASS" if ok else "FAIL"),'duplicate module')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'duplicate module');failed+=1
except Exception as e:
    print("FAIL",'duplicate module',str(e));failed+=1
try:
    ok=bool(eval("'unknown:F' in audit_layout([('A',0,0,3,2),('B',3,0,2,3),('C',5,0,2,2),('D',0,2,3,1),('E',7,0,2,2)]+[('F',8,6,1,1)])['errors']",scope))
    print(("PASS" if ok else "FAIL"),'unknown module')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'unknown module');failed+=1
except Exception as e:
    print("FAIL",'unknown module',str(e));failed+=1
try:
    ok=bool(eval("'outside:E' in audit_layout([('A',0,0,3,2),('B',3,0,2,3),('C',5,0,2,2),('D',0,2,3,1),('E',7,0,2,2)][:-1]+[('E',9,0,2,2)])['errors']",scope))
    print(("PASS" if ok else "FAIL"),'containment')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'containment');failed+=1
except Exception as e:
    print("FAIL",'containment',str(e));failed+=1
try:
    ok=bool(eval("'area:A' in audit_layout([('A',0,0,2,3.01)]+[('A',0,0,3,2),('B',3,0,2,3),('C',5,0,2,2),('D',0,2,3,1),('E',7,0,2,2)][1:])['errors']",scope))
    print(("PASS" if ok else "FAIL"),'area tolerance')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'area tolerance');failed+=1
except Exception as e:
    print("FAIL",'area tolerance',str(e));failed+=1
try:
    ok=bool(eval("'number:A' in audit_layout([('A',0,0,-2,-3)]+[('A',0,0,3,2),('B',3,0,2,3),('C',5,0,2,2),('D',0,2,3,1),('E',7,0,2,2)][1:])['errors']",scope))
    print(("PASS" if ok else "FAIL"),'negative dimensions')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'negative dimensions');failed+=1
except Exception as e:
    print("FAIL",'negative dimensions',str(e));failed+=1
try:
    ok=bool(eval("'number:A' in audit_layout([('A',0,0,2,0)]+[('A',0,0,3,2),('B',3,0,2,3),('C',5,0,2,2),('D',0,2,3,1),('E',7,0,2,2)][1:])['errors']",scope))
    print(("PASS" if ok else "FAIL"),'zero height')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'zero height');failed+=1
except Exception as e:
    print("FAIL",'zero height',str(e));failed+=1
try:
    ok=bool(eval("'number:A' in audit_layout([('A',float('nan'),0,3,2)]+[('A',0,0,3,2),('B',3,0,2,3),('C',5,0,2,2),('D',0,2,3,1),('E',7,0,2,2)][1:])['errors']",scope))
    print(("PASS" if ok else "FAIL"),'nonfinite values')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'nonfinite values');failed+=1
except Exception as e:
    print("FAIL",'nonfinite values',str(e));failed+=1
try:
    ok=bool(eval("'shape:B' in audit_layout([[('A',0,0,3,2),('B',3,0,2,3),('C',5,0,2,2),('D',0,2,3,1),('E',7,0,2,2)][0],('B',3,0,3,2)]+[('A',0,0,3,2),('B',3,0,2,3),('C',5,0,2,2),('D',0,2,3,1),('E',7,0,2,2)][2:])['errors']",scope))
    print(("PASS" if ok else "FAIL"),'no hard rotation')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'no hard rotation');failed+=1
except Exception as e:
    print("FAIL",'no hard rotation',str(e));failed+=1
try:
    ok=bool(eval("audit_layout([('A',0,0,2.5,2.4),('B',3,0,2,3),('C',5,0,2,2),('D',0,3,3,1),('E',7,0,2,2)],integer=False)['legal']",scope))
    print(("PASS" if ok else "FAIL"),'continuous allowed')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'continuous allowed');failed+=1
except Exception as e:
    print("FAIL",'continuous allowed',str(e));failed+=1
try:
    ok=bool(eval("'grid:A' in audit_layout([('A',0,0,2.5,2.4),('B',3,0,2,3),('C',5,0,2,2),('D',0,3,3,1),('E',7,0,2,2)],integer=True)['errors']",scope))
    print(("PASS" if ok else "FAIL"),'grid rejected')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'grid rejected');failed+=1
except Exception as e:
    print("FAIL",'grid rejected',str(e));failed+=1
try:
    ok=bool(eval("'aspect:A' in audit_layout([('A',0,0,3,2),('B',3,0,2,3),('C',5,0,2,2),('D',0,2,3,1),('E',7,0,2,2)],low=.9,high=1.1)['errors']",scope))
    print(("PASS" if ok else "FAIL"),'ratio parameters respected')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'ratio parameters respected');failed+=1
except Exception as e:
    print("FAIL",'ratio parameters respected',str(e));failed+=1
try:
    ok=bool(eval("audit_layout([('A',0,0,2,4),('B',2,0,2,3),('C',4,0,2,2),('D',0,4,3,1),('E',4,2,2,2)],area=8)['legal']",scope))
    print(("PASS" if ok else "FAIL"),'area-eight endpoint')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'area-eight endpoint');failed+=1
except Exception as e:
    print("FAIL",'area-eight endpoint',str(e));failed+=1
try:
    ok=bool(eval("audit_layout([('A',0,0,2,4),('B',2,0,2,3),('C',4,0,2,2),('D',0,4,3,1),('E',4,2,2,2)],area=8)['dead_space']==5",scope))
    print(("PASS" if ok else "FAIL"),'area-eight totals')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'area-eight totals');failed+=1
except Exception as e:
    print("FAIL",'area-eight totals',str(e));failed+=1
raise SystemExit(1 if failed else 0)

# Lesson 06

实现完整解码器 decode_sequence_pair(pos, neg, modules)：校验两行排列，把全部有序对分类成水平/竖直约束（同序→水平，反序→竖直），按拓扑序（pos 本身）对每个模块取所有前驱下界的最大值，返回图、顺序、坐标、关键前驱与rows。边权用前驱的尺寸。错误码：permutation:pos / permutation:neg。

Implement the full decoder decode_sequence_pair(pos, neg, modules): validate both permutations, classify every ordered pair (same order -> horizontal, reversed -> vertical), then walk pos as a topological order taking the maximum of all predecessor bounds. Edge weight is the predecessor size. Return graph, order, coords, key predecessors and rows. Error code: permutation:pos / permutation:neg.

Run from this folder:

```
python check.py starter.py
python check.py reference.py
```

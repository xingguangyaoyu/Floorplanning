import importlib.util,math,sys
from pathlib import Path
p=Path(sys.argv[1] if len(sys.argv)>1 else "starter.py")
spec=importlib.util.spec_from_file_location("student",p);student=importlib.util.module_from_spec(spec);spec.loader.exec_module(student)
scope=dict(vars(student));scope["math"]=math
def raises_value_error(f):
    try:f()
    except ValueError:return True
    return False
scope["raises_value_error"]=raises_value_error
failed=0
try:
    ok=bool(eval('decode_sequence_pair(*(\'ABCED\',\'DABCE\'),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'ok\'] is True and validate_layout(decode_sequence_pair(*(\'ABCED\',\'DABCE\'),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'rows\'],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'legal\'] is True',scope))
    print(("PASS" if ok else "FAIL"),'standard encoding decodes legally')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'standard encoding decodes legally');failed+=1
except Exception as e:
    print("FAIL",'standard encoding decodes legally',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: r[\'coords\'][\'A\']==(0,0,3,2) and r[\'coords\'][\'B\']==(3,0,2,3) and r[\'coords\'][\'C\']==(5,0,2,2) and r[\'coords\'][\'E\']==(7,0,2,2) and r[\'coords\'][\'D\']==(0,3,3,1))(decode_sequence_pair(*(\'ABCED\',\'DABCE\'),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}))',scope))
    print(("PASS" if ok else "FAIL"),'standard coordinates')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'standard coordinates');failed+=1
except Exception as e:
    print("FAIL",'standard coordinates',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: len(r[\'graph\'][\'H\'])+len(r[\'graph\'][\'V\'])==10 and r[\'graph\'][\'H\']==[(\'A\',\'B\'),(\'A\',\'C\'),(\'A\',\'E\'),(\'B\',\'C\'),(\'B\',\'E\'),(\'C\',\'E\')])(decode_sequence_pair(*(\'ABCED\',\'DABCE\'),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}))',scope))
    print(("PASS" if ok else "FAIL"),'ten pairs classified once')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'ten pairs classified once');failed+=1
except Exception as e:
    print("FAIL",'ten pairs classified once',str(e));failed+=1
try:
    ok=bool(eval('decode_sequence_pair(*(\'ABCED\',\'DABCE\'),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'order\']==list(\'ABCED\')',scope))
    print(("PASS" if ok else "FAIL"),'pos itself is the topological order')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'pos itself is the topological order');failed+=1
except Exception as e:
    print("FAIL",'pos itself is the topological order',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: r[\'graph\'][\'V\']==[(\'A\',\'D\'),(\'B\',\'D\'),(\'C\',\'D\'),(\'E\',\'D\')])(decode_sequence_pair(*(\'ABCED\',\'DABCE\'),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}))',scope))
    print(("PASS" if ok else "FAIL"),'D has four vertical predecessors')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'D has four vertical predecessors');failed+=1
except Exception as e:
    print("FAIL",'D has four vertical predecessors',str(e));failed+=1
try:
    ok=bool(eval('decode_sequence_pair(*(\'ABCED\',\'DABCE\'),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'key\'][\'D\'][\'y\']==\'B\'',scope))
    print(("PASS" if ok else "FAIL"),'B is the key vertical predecessor of D')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'B is the key vertical predecessor of D');failed+=1
except Exception as e:
    print("FAIL",'B is the key vertical predecessor of D',str(e));failed+=1
try:
    ok=bool(eval('decode_sequence_pair(*(\'ABCED\',\'DABCE\'),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'key\'][\'C\'][\'y\'] is None',scope))
    print(("PASS" if ok else "FAIL"),'C has no vertical predecessor')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'C has no vertical predecessor');failed+=1
except Exception as e:
    print("FAIL",'C has no vertical predecessor',str(e));failed+=1
try:
    ok=bool(eval('decode_sequence_pair(*(\'ABCED\',\'DABCE\'),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'coords\'][\'D\'][1]==3',scope))
    print(("PASS" if ok else "FAIL"),'max not sum for coordinates')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'max not sum for coordinates');failed+=1
except Exception as e:
    print("FAIL",'max not sum for coordinates',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: r[\'coords\'][\'E\']==(10,0,2,2) and max(x+w for i,x,y,w,h in r[\'rows\'])==12)(decode_sequence_pair(\'ABCDE\',\'ABCDE\',{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}))',scope))
    print(("PASS" if ok else "FAIL"),'row encoding overflows to width 12')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'row encoding overflows to width 12');failed+=1
except Exception as e:
    print("FAIL",'row encoding overflows to width 12',str(e));failed+=1
try:
    ok=bool(eval('validate_layout(decode_sequence_pair(\'ABCDE\',\'ABCDE\',{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'rows\'],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'legal\'] is False',scope))
    print(("PASS" if ok else "FAIL"),'row encoding is not a legal layout')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'row encoding is not a legal layout');failed+=1
except Exception as e:
    print("FAIL",'row encoding is not a legal layout',str(e));failed+=1
try:
    ok=bool(eval('decode_sequence_pair(\'ABCED\',\'DABCE\',\'DABCE\') if False else decode_sequence_pair(\'ABCED\',\'DABC\',{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'ok\'] is False and \'permutation:neg\' in decode_sequence_pair(\'ABCED\',\'DABC\',{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'errors\'][0]',scope))
    print(("PASS" if ok else "FAIL"),'bad permutation is rejected')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'bad permutation is rejected');failed+=1
except Exception as e:
    print("FAIL",'bad permutation is rejected',str(e));failed+=1
try:
    ok=bool(eval('decode_sequence_pair(\'ABCED\',\'DABCC\',{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'ok\'] is False',scope))
    print(("PASS" if ok else "FAIL"),'duplicate in a row is rejected')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'duplicate in a row is rejected');failed+=1
except Exception as e:
    print("FAIL",'duplicate in a row is rejected',str(e));failed+=1
try:
    ok=bool(eval('decode_sequence_pair(\'ABCED\',\'DABCF\',{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'ok\'] is False',scope))
    print(("PASS" if ok else "FAIL"),'unknown module is rejected')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'unknown module is rejected');failed+=1
except Exception as e:
    print("FAIL",'unknown module is rejected',str(e));failed+=1
try:
    ok=bool(eval('(lambda a,b: a[\'coords\']==b[\'coords\'] and a[\'coords\'][\'C\']==(3,3,2,2) and a[\'coords\'][\'E\']==(5,3,2,2))(decode_sequence_pair(\'ABDCE\',\'DACEB\',{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}), decode_sequence_pair(\'ABDCE\',\'DCAEB\',{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}))',scope))
    print(("PASS" if ok else "FAIL"),'multi-encoding: two encodings agree exactly')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'multi-encoding: two encodings agree exactly');failed+=1
except Exception as e:
    print("FAIL",'multi-encoding: two encodings agree exactly',str(e));failed+=1
try:
    ok=bool(eval('validate_layout(decode_sequence_pair(\'ABDCE\',\'DACEB\',{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'rows\'],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'legal\'] is True',scope))
    print(("PASS" if ok else "FAIL"),'multi-encoding layout is legal')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'multi-encoding layout is legal');failed+=1
except Exception as e:
    print("FAIL",'multi-encoding layout is legal',str(e));failed+=1
try:
    ok=bool(eval('decode_sequence_pair(\'ABDCE\',\'DACEB\',{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'key\'][\'C\'][\'x\'] in (\'A\',\'D\')',scope))
    print(("PASS" if ok else "FAIL"),'key x predecessor of C in the multi encoding')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'key x predecessor of C in the multi encoding');failed+=1
except Exception as e:
    print("FAIL",'key x predecessor of C in the multi encoding',str(e));failed+=1
try:
    ok=bool(eval('(lambda r, mc: all(r[\'coords\'][q][0]>=r[\'coords\'][p][0]+mc[p][0] for (p,q) in r[\'graph\'][\'H\']) and all(r[\'coords\'][q][1]>=r[\'coords\'][p][1]+mc[p][1] for (p,q) in r[\'graph\'][\'V\']))(decode_sequence_pair(*(\'ABCED\',\'DABCE\'),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}), {"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})',scope))
    print(("PASS" if ok else "FAIL"),'horizontal bounds bind x and vertical bounds bind y')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'horizontal bounds bind x and vertical bounds bind y');failed+=1
except Exception as e:
    print("FAIL",'horizontal bounds bind x and vertical bounds bind y',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: r[\'coords\'][\'D\'][1]==max(r[\'coords\'][p][1]+{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}[p][1] for (p,q) in r[\'graph\'][\'V\'] if q==\'D\'))(decode_sequence_pair(*(\'ABCED\',\'DABCE\'),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}))',scope))
    print(("PASS" if ok else "FAIL"),'coords are minimal: dropping below any key bound breaks a constraint')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'coords are minimal: dropping below any key bound breaks a constraint');failed+=1
except Exception as e:
    print("FAIL",'coords are minimal: dropping below any key bound breaks a constraint',str(e));failed+=1
try:
    ok=bool(eval("decode_sequence_pair('PQ','PQ',{'P':(1.5,2),'Q':(1,2)})['coords']['Q']==(1.5,0,1,2)",scope))
    print(("PASS" if ok else "FAIL"),'decimal modules keep precision')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'decimal modules keep precision');failed+=1
except Exception as e:
    print("FAIL",'decimal modules keep precision',str(e));failed+=1
try:
    ok=bool(eval('(lambda p,n: (decode_sequence_pair(p,n,{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}), \'\'.join(p)==\'ABCED\' and \'\'.join(n)==\'DABCE\')[1])(list(\'ABCED\'),list(\'DABCE\'))',scope))
    print(("PASS" if ok else "FAIL"),'inputs are not mutated')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'inputs are not mutated');failed+=1
except Exception as e:
    print("FAIL",'inputs are not mutated',str(e));failed+=1
try:
    ok=bool(eval("decode_sequence_pair('PQ','PQ',{'P':(3,2),'Q':(1,2)})['coords']['Q']==(3,0,1,2)",scope))
    print(("PASS" if ok else "FAIL"),'two-module catalog works independently')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'two-module catalog works independently');failed+=1
except Exception as e:
    print("FAIL",'two-module catalog works independently',str(e));failed+=1
try:
    ok=bool(eval("decode_sequence_pair('PQ','QP',{'P':(3,2),'Q':(1,2)})['coords']['Q']==(0,2,1,2)",scope))
    print(("PASS" if ok else "FAIL"),'vertical constraint lifts the later module')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'vertical constraint lifts the later module');failed+=1
except Exception as e:
    print("FAIL",'vertical constraint lifts the later module',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: all(r[\'order\'].index(a)<r[\'order\'].index(b) for (a,b) in r[\'graph\'][\'H\']+r[\'graph\'][\'V\']))(decode_sequence_pair(*(\'ABCED\',\'DABCE\'),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}))',scope))
    print(("PASS" if ok else "FAIL"),'graph is acyclic by construction: edges follow pos order')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'graph is acyclic by construction: edges follow pos order');failed+=1
except Exception as e:
    print("FAIL",'graph is acyclic by construction: edges follow pos order',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: [row[0] for row in r[\'rows\']]==[\'A\',\'B\',\'C\',\'D\',\'E\'])(decode_sequence_pair(*(\'ABCED\',\'DABCE\'),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}))',scope))
    print(("PASS" if ok else "FAIL"),'rows are sorted and complete')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'rows are sorted and complete');failed+=1
except Exception as e:
    print("FAIL",'rows are sorted and complete',str(e));failed+=1
raise SystemExit(1 if failed else 0)

import math

def validate_layout(rows, outline, catalog):
    errors, seen, good, overlaps = set(), set(), [], []
    width, height = outline
    for row in rows:
        name, x, y, w, h = row
        if name in seen: errors.add('duplicate:' + name)
        seen.add(name)
        if name not in catalog: errors.add('unknown:' + name)
        if not all(isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v) for v in (x,y,w,h)) or w <= 0 or h <= 0:
            errors.add('number:' + name)
            continue
        good.append(row)
        if name in catalog and (w,h) != tuple(catalog[name]): errors.add('shape:' + name)
        if x < 0 or y < 0 or x+w > width or y+h > height: errors.add('outside:' + name)
    for name in catalog:
        if name not in seen: errors.add('missing:' + name)
    for i,(a,x,y,w,h) in enumerate(good):
        for b,X,Y,W,H in good[i+1:]:
            dx = max(0, min(x+w,X+W)-max(x,X))
            dy = max(0, min(y+h,Y+H)-max(y,Y))
            if dx > 0 and dy > 0:
                ids = sorted([a,b])
                errors.add('overlap:' + '/'.join(ids))
                overlaps.append({'ids':ids, 'area':dx*dy})
    overlaps.sort(key=lambda item:(item['ids'], item['area']))
    return {'legal':not errors, 'errors':sorted(errors), 'overlaps':overlaps}

def combine(a, b, op):
    if op == 'H': return (max(a[0], b[0]), a[1] + b[1])
    if op == 'V': return (a[0] + b[0], max(a[1], b[1]))
    raise ValueError('Unknown operator')

def decode_postfix(tokens, catalog):
    stack = []      # each item: (node, (w, h)); node carries its size
    seen = set()
    errors = []

    for token in tokens:
        if token in ('H', 'V'):
            if len(stack) < 2:
                errors.append(f'underflow:{token}')
                break
            b = stack.pop()   # popped first -> second region
            a = stack.pop()   # popped second -> first region
            (wa, ha), (wb, hb) = a[1], b[1]
            size = (max(wa, wb), ha + hb) if token == 'H' else (wa + wb, max(ha, hb))
            node = {'op': token, 'left': a[0], 'right': b[0], 'size': size}
            stack.append((node, size))
        else:
            if token not in catalog:
                errors.append(f'unknown:{token}')
                break
            if token in seen:
                errors.append(f'duplicate:{token}')
                break
            seen.add(token)
            w, h = catalog[token]
            stack.append(({'id': token, 'size': (w, h)}, (w, h)))

    if errors:
        return {'ok': False, 'errors': errors, 'tree': None, 'size': None,
                'coords': None, 'rows': []}
    missing = [i for i in catalog if i not in seen]
    if missing:
        return {'ok': False, 'errors': ['missing:' + ','.join(missing)], 'tree': None,
                'size': None, 'coords': None, 'rows': []}
    if len(stack) != 1:
        return {'ok': False, 'errors': [f'leftover:{len(stack)}'], 'tree': None,
                'size': None, 'coords': None, 'rows': []}

    root, root_size = stack[0]
    coords = {}
    def place(node, x, y):
        if 'id' in node:
            coords[node['id']] = (x, y, *node['size'])
            return
        lw, lh = node['left']['size']
        if node['op'] == 'H':
            place(node['left'], x, y)                  # first region below
            place(node['right'], x, y + lh)            # second region above
        else:
            place(node['left'], x, y)                  # first region left
            place(node['right'], x + lw, y)            # second region right

    place(root, 0, 0)
    rows = [[i, *coords[i]] for i in sorted(coords)]
    return {'ok': True, 'errors': [], 'tree': root, 'size': root_size,
            'coords': coords, 'rows': rows}

# Provided: the Lab4 postfix decoder (already complete). Use it to realize
# each shape combination as concrete rows before measuring (width, height).
import math

def validate_layout(rows, outline, catalog):
    errors, seen, good, overlaps = set(), set(), [], []
    width, height = outline
    for row in rows:
        name, x, y, w, h = row
        if name in seen: errors.add('duplicate:' + name)
        seen.add(name)
        if name not in catalog: errors.add('unknown:' + name)
        if not all(isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v) for v in (x,y,w,h)) or w <= 0 or h <= 0:
            errors.add('number:' + name)
            continue
        good.append(row)
        if name in catalog and (w,h) != tuple(catalog[name]): errors.add('shape:' + name)
        if x < 0 or y < 0 or x+w > width or y+h > height: errors.add('outside:' + name)
    for name in catalog:
        if name not in seen: errors.add('missing:' + name)
    for i,(a,x,y,w,h) in enumerate(good):
        for b,X,Y,W,H in good[i+1:]:
            dx = max(0, min(x+w,X+W)-max(x,X))
            dy = max(0, min(y+h,Y+H)-max(y,Y))
            if dx > 0 and dy > 0:
                ids = sorted([a,b])
                errors.add('overlap:' + '/'.join(ids))
                overlaps.append({'ids':ids, 'area':dx*dy})
    overlaps.sort(key=lambda item:(item['ids'], item['area']))
    return {'legal':not errors, 'errors':sorted(errors), 'overlaps':overlaps}

def combine(a, b, op):
    if op == 'H': return (max(a[0], b[0]), a[1] + b[1])
    if op == 'V': return (a[0] + b[0], max(a[1], b[1]))
    raise ValueError('Unknown operator')

def decode_postfix(tokens, catalog):
    stack = []      # each item: (node, (w, h)); node carries its size
    seen = set()
    errors = []

    for token in tokens:
        if token in ('H', 'V'):
            if len(stack) < 2:
                errors.append(f'underflow:{token}')
                break
            b = stack.pop()   # popped first -> second region
            a = stack.pop()   # popped second -> first region
            (wa, ha), (wb, hb) = a[1], b[1]
            size = (max(wa, wb), ha + hb) if token == 'H' else (wa + wb, max(ha, hb))
            node = {'op': token, 'left': a[0], 'right': b[0], 'size': size}
            stack.append((node, size))
        else:
            if token not in catalog:
                errors.append(f'unknown:{token}')
                break
            if token in seen:
                errors.append(f'duplicate:{token}')
                break
            seen.add(token)
            w, h = catalog[token]
            stack.append(({'id': token, 'size': (w, h)}, (w, h)))

    if errors:
        return {'ok': False, 'errors': errors, 'tree': None, 'size': None,
                'coords': None, 'rows': []}
    missing = [i for i in catalog if i not in seen]
    if missing:
        return {'ok': False, 'errors': ['missing:' + ','.join(missing)], 'tree': None,
                'size': None, 'coords': None, 'rows': []}
    if len(stack) != 1:
        return {'ok': False, 'errors': [f'leftover:{len(stack)}'], 'tree': None,
                'size': None, 'coords': None, 'rows': []}

    root, root_size = stack[0]
    coords = {}
    def place(node, x, y):
        if 'id' in node:
            coords[node['id']] = (x, y, *node['size'])
            return
        lw, lh = node['left']['size']
        if node['op'] == 'H':
            place(node['left'], x, y)                  # first region below
            place(node['right'], x, y + lh)            # second region above
        else:
            place(node['left'], x, y)                  # first region left
            place(node['right'], x + lw, y)            # second region right

    place(root, 0, 0)
    rows = [[i, *coords[i]] for i in sorted(coords)]
    return {'ok': True, 'errors': [], 'tree': root, 'size': root_size,
            'coords': coords, 'rows': rows}


def feasible(rows, outline):
    # Generic fixed-outline + pairwise-overlap check for decoded rows.
    ok = all(0 <= r[1] and 0 <= r[2] and r[1] + r[3] <= outline[0] + 1e-9
             and r[2] + r[4] <= outline[1] + 1e-9 for r in rows)
    for i in range(len(rows)):
        for j in range(i + 1, len(rows)):
            a, b = rows[i], rows[j]
            if a[1] < b[1] + b[3] - 1e-9 and b[1] < a[1] + a[3] - 1e-9 and \
               a[2] < b[2] + b[4] - 1e-9 and b[2] < a[2] + a[4] - 1e-9:
                ok = False
    return ok

def shape_frontier(tree, candidates, outline):
    # Enumerate every shape combination, decode the tree for each, and keep
    # the non-dominated (width, height) pairs. Dominance: another candidate
    # has width AND height both no larger, with at least one strictly smaller.
    ids = sorted(candidates)
    combos = []
    def walk(i, choice):
        if i == len(ids):
            combos.append(dict(choice)); return
        for s in range(len(candidates[ids[i]])):
            choice[ids[i]] = s
            walk(i + 1, choice)
    walk(0, {})

    decoded = []
    for choice in combos:
        catalog = {i: tuple(candidates[i][choice[i]]) for i in ids}
        rows = decode_postfix(tree, catalog)['rows']
        W = max(r[1] + r[3] for r in rows)
        H = max(r[2] + r[4] for r in rows)
        decoded.append({'choice': dict(choice), 'size': (W, H), 'area': W * H,
                        'rows': rows,
                        'fit': W <= outline[0] and H <= outline[1]})
    decoded.sort(key=lambda c: (c['area'], c['size']))

    frontier = [c for c in decoded
                if not any(o is not c
                           and o['size'][0] <= c['size'][0]
                           and o['size'][1] <= c['size'][1]
                           and (o['size'][0] < c['size'][0] or o['size'][1] < c['size'][1])
                           for o in decoded)]
    return {'candidates': decoded, 'frontier': frontier,
            'fitting': [c for c in decoded if c['fit']]}

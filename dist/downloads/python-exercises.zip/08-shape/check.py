import importlib.util,math,sys
from pathlib import Path
p=Path(sys.argv[1] if len(sys.argv)>1 else "starter.py")
spec=importlib.util.spec_from_file_location("student",p);student=importlib.util.module_from_spec(spec);spec.loader.exec_module(student)
scope=dict(vars(student));scope["math"]=math
def raises_value_error(f):
    try:f()
    except ValueError:return True
    return False
scope["raises_value_error"]=raises_value_error
failed=0
try:
    ok=bool(eval('len(shape_frontier([\'A\',\'B\',\'V\',\'C\',\'H\'],{"A":[[2,3],[3,2]],"B":[[3,4],[4,3]],"C":[[3,1]]},[5,5])[\'candidates\'])==4',scope))
    print(("PASS" if ok else "FAIL"),'four combinations enumerated')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'four combinations enumerated');failed+=1
except Exception as e:
    print("FAIL",'four combinations enumerated',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: [c[\'area\'] for c in r[\'candidates\']]==[24,25,28,30])(shape_frontier([\'A\',\'B\',\'V\',\'C\',\'H\'],{"A":[[2,3],[3,2]],"B":[[3,4],[4,3]],"C":[[3,1]]},[5,5]))',scope))
    print(("PASS" if ok else "FAIL"),'candidates sorted by area')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'candidates sorted by area');failed+=1
except Exception as e:
    print("FAIL",'candidates sorted by area',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: [ (c[\'size\'][0],c[\'size\'][1]) for c in r[\'frontier\']]==[(6,4),(5,5)])(shape_frontier([\'A\',\'B\',\'V\',\'C\',\'H\'],{"A":[[2,3],[3,2]],"B":[[3,4],[4,3]],"C":[[3,1]]},[5,5]))',scope))
    print(("PASS" if ok else "FAIL"),'dominated candidates are removed')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'dominated candidates are removed');failed+=1
except Exception as e:
    print("FAIL",'dominated candidates are removed',str(e));failed+=1
try:
    ok=bool(eval('all(c[\'size\']!=(7,4) and c[\'size\']!=(6,5) for c in shape_frontier([\'A\',\'B\',\'V\',\'C\',\'H\'],{"A":[[2,3],[3,2]],"B":[[3,4],[4,3]],"C":[[3,1]]},[5,5])[\'frontier\'])',scope))
    print(("PASS" if ok else "FAIL"),'(6,5) and (7,4) do not survive')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'(6,5) and (7,4) do not survive');failed+=1
except Exception as e:
    print("FAIL",'(6,5) and (7,4) do not survive',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: [c[\'rows\'] for c in r[\'frontier\'] if c[\'area\']==24][0]==[[\'A\',0,0,2,3],[\'B\',2,0,4,3],[\'C\',0,3,3,1]])(shape_frontier([\'A\',\'B\',\'V\',\'C\',\'H\'],{"A":[[2,3],[3,2]],"B":[[3,4],[4,3]],"C":[[3,1]]},[5,5]))',scope))
    print(("PASS" if ok else "FAIL"),'frontier rows for 24 match the taught witness')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'frontier rows for 24 match the taught witness');failed+=1
except Exception as e:
    print("FAIL",'frontier rows for 24 match the taught witness',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: [c[\'rows\'] for c in r[\'frontier\'] if c[\'area\']==25][0]==[[\'A\',0,0,2,3],[\'B\',2,0,3,4],[\'C\',0,4,3,1]])(shape_frontier([\'A\',\'B\',\'V\',\'C\',\'H\'],{"A":[[2,3],[3,2]],"B":[[3,4],[4,3]],"C":[[3,1]]},[5,5]))',scope))
    print(("PASS" if ok else "FAIL"),'frontier rows for 25 match the taught witness')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'frontier rows for 25 match the taught witness');failed+=1
except Exception as e:
    print("FAIL",'frontier rows for 25 match the taught witness',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: [c[\'choice\'] for c in r[\'frontier\']]==[{\'A\':0,\'B\':1,\'C\':0},{\'A\':0,\'B\':0,\'C\':0}])(shape_frontier([\'A\',\'B\',\'V\',\'C\',\'H\'],{"A":[[2,3],[3,2]],"B":[[3,4],[4,3]],"C":[[3,1]]},[5,5]))',scope))
    print(("PASS" if ok else "FAIL"),'source pointers record the chosen shape index')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'source pointers record the chosen shape index');failed+=1
except Exception as e:
    print("FAIL",'source pointers record the chosen shape index',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: [(c[\'area\'],c[\'fit\']) for c in r[\'candidates\']]==[(24,False),(25,True),(28,False),(30,False)])(shape_frontier([\'A\',\'B\',\'V\',\'C\',\'H\'],{"A":[[2,3],[3,2]],"B":[[3,4],[4,3]],"C":[[3,1]]},[5,5]))',scope))
    print(("PASS" if ok else "FAIL"),'fit flag respects the outline')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'fit flag respects the outline');failed+=1
except Exception as e:
    print("FAIL",'fit flag respects the outline',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: [c[\'area\'] for c in r[\'fitting\']]==[25])(shape_frontier([\'A\',\'B\',\'V\',\'C\',\'H\'],{"A":[[2,3],[3,2]],"B":[[3,4],[4,3]],"C":[[3,1]]},[5,5]))',scope))
    print(("PASS" if ok else "FAIL"),'fitting keeps only layouts inside the outline')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'fitting keeps only layouts inside the outline');failed+=1
except Exception as e:
    print("FAIL",'fitting keeps only layouts inside the outline',str(e));failed+=1
try:
    ok=bool(eval('all(feasible(c[\'rows\'],[7,5]) for c in shape_frontier([\'A\',\'B\',\'V\',\'C\',\'H\'],{"A":[[2,3],[3,2]],"B":[[3,4],[4,3]],"C":[[3,1]]},[5,5])[\'frontier\']) and all(feasible(c[\'rows\'],[5,5]) for c in shape_frontier([\'A\',\'B\',\'V\',\'C\',\'H\'],{"A":[[2,3],[3,2]],"B":[[3,4],[4,3]],"C":[[3,1]]},[5,5])[\'fitting\'])',scope))
    print(("PASS" if ok else "FAIL"),'frontier rows fit a wider outline and the fitting ones fit the taught one')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'frontier rows fit a wider outline and the fitting ones fit the taught one');failed+=1
except Exception as e:
    print("FAIL",'frontier rows fit a wider outline and the fitting ones fit the taught one',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: [ (c[\'size\'][0],c[\'size\'][1]) for c in r[\'frontier\']]==[(7,5),(6,6)])(shape_frontier([\'A\',\'B\',\'H\',\'C\',\'V\'],{"A":[[2,3],[3,2]],"B":[[3,4],[4,3]],"C":[[3,1]]},[5,5]))',scope))
    print(("PASS" if ok else "FAIL"),'different tree changes the frontier')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'different tree changes the frontier');failed+=1
except Exception as e:
    print("FAIL",'different tree changes the frontier',str(e));failed+=1
try:
    ok=bool(eval('len(shape_frontier([\'A\',\'B\',\'H\',\'C\',\'V\'],{"A":[[2,3],[3,2]],"B":[[3,4],[4,3]],"C":[[3,1]]},[5,5])[\'candidates\'])==4',scope))
    print(("PASS" if ok else "FAIL"),'variant tree candidate count is still four')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'variant tree candidate count is still four');failed+=1
except Exception as e:
    print("FAIL",'variant tree candidate count is still four',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: [c[\'area\'] for c in r[\'fitting\']]==[24,25,28,30])(shape_frontier([\'A\',\'B\',\'V\',\'C\',\'H\'],{"A":[[2,3],[3,2]],"B":[[3,4],[4,3]],"C":[[3,1]]},[7,5]))',scope))
    print(("PASS" if ok else "FAIL"),'larger outline admits more candidates')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'larger outline admits more candidates');failed+=1
except Exception as e:
    print("FAIL",'larger outline admits more candidates',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: [ (c[\'size\'][0],c[\'size\'][1]) for c in r[\'frontier\']]==[(6,4),(5,5)])(shape_frontier([\'A\',\'B\',\'V\',\'C\',\'H\'],{"A":[[2,3],[3,2]],"B":[[3,4],[4,3]],"C":[[3,1]]},[7,5]))',scope))
    print(("PASS" if ok else "FAIL"),'frontier is independent of outline')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'frontier is independent of outline');failed+=1
except Exception as e:
    print("FAIL",'frontier is independent of outline',str(e));failed+=1
try:
    ok=bool(eval("(lambda r: r['frontier'][0]['size']==(3.5,4))(shape_frontier(['A','B','V','C','H'],{'A':[[1.5,4],[2,3]],'B':[[2,4]],'C':[[3,1]]},[5,5])) if False else shape_frontier(['A','B','V','C','H'],{'A':[[2,3]],'B':[[3,4]],'C':[[3,1]]},[5,5])['frontier'][0]['area']==25",scope))
    print(("PASS" if ok else "FAIL"),'decimal candidate shapes keep precision')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'decimal candidate shapes keep precision');failed+=1
except Exception as e:
    print("FAIL",'decimal candidate shapes keep precision',str(e));failed+=1
try:
    ok=bool(eval("(lambda r: [ (c['size'][0],c['size'][1]) for c in r['frontier']]==[(6,4),(5,5)])(shape_frontier(['A','B','V','C','H'],{'B':[[3,4],[4,3]],'A':[[2,3],[3,2]],'C':[[3,1]]},[5,5]))",scope))
    print(("PASS" if ok else "FAIL"),'candidate order does not change the frontier')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'candidate order does not change the frontier');failed+=1
except Exception as e:
    print("FAIL",'candidate order does not change the frontier',str(e));failed+=1
try:
    ok=bool(eval('all(any(r[0]==\'A\' and r[3]==sw[0] and r[4]==sw[1] for r in c[\'rows\']) for c in shape_frontier([\'A\',\'B\',\'V\',\'C\',\'H\'],{"A":[[2,3],[3,2]],"B":[[3,4],[4,3]],"C":[[3,1]]},[5,5])[\'candidates\'] for sw in [ (2,3) if c[\'choice\'][\'A\']==0 else (3,2) ])',scope))
    print(("PASS" if ok else "FAIL"),'rows realize the chosen shapes exactly')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'rows realize the chosen shapes exactly');failed+=1
except Exception as e:
    print("FAIL",'rows realize the chosen shapes exactly',str(e));failed+=1
try:
    ok=bool(eval('all(len(c[\'rows\'])==3 for c in shape_frontier([\'A\',\'B\',\'V\',\'C\',\'H\'],{"A":[[2,3],[3,2]],"B":[[3,4],[4,3]],"C":[[3,1]]},[5,5])[\'candidates\'])',scope))
    print(("PASS" if ok else "FAIL"),'all four combinations decode without error')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'all four combinations decode without error');failed+=1
except Exception as e:
    print("FAIL",'all four combinations decode without error',str(e));failed+=1
try:
    ok=bool(eval('len(shape_frontier([\'A\',\'B\',\'V\',\'C\',\'H\'],{"A":[[2,3],[3,2]],"B":[[3,4],[4,3]],"C":[[3,1]]},[5,5])[\'frontier\'])==2',scope))
    print(("PASS" if ok else "FAIL"),'frontier size is two for this instance')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'frontier size is two for this instance');failed+=1
except Exception as e:
    print("FAIL",'frontier size is two for this instance',str(e));failed+=1
try:
    ok=bool(eval("(lambda c: (shape_frontier(['A','B','V','C','H'],c,[5,5]), c['A']==[[2,3],[3,2]])[1])({'A':[[2,3],[3,2]],'B':[[3,4],[4,3]],'C':[[3,1]]})",scope))
    print(("PASS" if ok else "FAIL"),'input candidates are not mutated')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'input candidates are not mutated');failed+=1
except Exception as e:
    print("FAIL",'input candidates are not mutated',str(e));failed+=1
try:
    ok=bool(eval('set(c[\'area\'] for c in shape_frontier([\'A\',\'B\',\'V\',\'C\',\'H\'],{"A":[[2,3],[3,2]],"B":[[3,4],[4,3]],"C":[[3,1]]},[5,5])[\'fitting\'])<=set(c[\'area\'] for c in shape_frontier([\'A\',\'B\',\'V\',\'C\',\'H\'],{"A":[[2,3],[3,2]],"B":[[3,4],[4,3]],"C":[[3,1]]},[5,5])[\'frontier\'])',scope))
    print(("PASS" if ok else "FAIL"),'fitting subset of frontier is consistent')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'fitting subset of frontier is consistent');failed+=1
except Exception as e:
    print("FAIL",'fitting subset of frontier is consistent',str(e));failed+=1
try:
    ok=bool(eval('sum(c[\'area\'] for c in shape_frontier([\'A\',\'B\',\'V\',\'C\',\'H\'],{"A":[[2,3],[3,2]],"B":[[3,4],[4,3]],"C":[[3,1]]},[5,5])[\'frontier\'])==49',scope))
    print(("PASS" if ok else "FAIL"),'sum of frontier areas for the taught example')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'sum of frontier areas for the taught example');failed+=1
except Exception as e:
    print("FAIL",'sum of frontier areas for the taught example',str(e));failed+=1
raise SystemExit(1 if failed else 0)

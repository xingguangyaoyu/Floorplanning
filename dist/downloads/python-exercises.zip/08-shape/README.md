# Lesson 08-shape

实现 shape_frontier(tree, candidates, outline)：枚举全部形状组合，用已提供的 Lab4 解码器把每个组合变成具体 rows，测出 (宽,高)，做支配删除（另一候选宽和高都不更大、至少一维严格更小），返回 candidates（按面积排序）、frontier、fitting（放进 outline 的子集），每个候选带 choice 来源指针与可回溯 rows。

Implement shape_frontier(tree, candidates, outline): enumerate all shape combinations, realize each as concrete rows via the provided Lab4 decoder, measure (width,height), apply dominance filtering (another candidate with both dimensions no larger and one strictly smaller), and return candidates (sorted by area), frontier and fitting (those inside outline), each with its choice pointer and backtracked rows.

Run from this folder:

```
python check.py starter.py
python check.py reference.py
```

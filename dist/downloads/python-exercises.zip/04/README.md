# Lesson 04

实现完整解码器 decode_postfix(tokens, catalog)：解析后缀表达式，生成切片树，自下而上算尺寸、自上而下算坐标；返回树、尺寸、坐标与可读错误。已提供 combine 与 Lab2 的 validate_layout 作辅助。约定：H 的第一区域在下、第二区域在上；V 的第一区域在左、第二区域在右；先弹出的是第二区域。错误码：underflow:X、leftover:N、unknown:X、duplicate:X、missing:清单。

Implement the full decoder decode_postfix(tokens, catalog): parse the postfix expression, build the slicing tree, aggregate sizes bottom-up and propagate coordinates top-down. Helpers combine and the Lab2 validate_layout are provided. Convention: H places the first region below the second; V places the first left of the second; the first pop is the second region. Error codes: underflow:X, leftover:N, unknown:X, duplicate:X, missing:list.

Run from this folder:

```
python check.py starter.py
python check.py reference.py
```

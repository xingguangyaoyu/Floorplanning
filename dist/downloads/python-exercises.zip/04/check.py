import importlib.util,math,sys
from pathlib import Path
p=Path(sys.argv[1] if len(sys.argv)>1 else "starter.py")
spec=importlib.util.spec_from_file_location("student",p);student=importlib.util.module_from_spec(spec);spec.loader.exec_module(student)
scope=dict(vars(student));scope["math"]=math
def raises_value_error(f):
    try:f()
    except ValueError:return True
    return False
scope["raises_value_error"]=raises_value_error
failed=0
try:
    ok=bool(eval('decode_postfix([\'A\',\'D\',\'H\',\'B\',\'V\',\'C\',\'V\',\'E\',\'V\'],{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'size\']==(9,3)',scope))
    print(("PASS" if ok else "FAIL"),'standard expression decodes to 9x3')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'standard expression decodes to 9x3');failed+=1
except Exception as e:
    print("FAIL",'standard expression decodes to 9x3',str(e));failed+=1
try:
    ok=bool(eval('decode_postfix([\'A\',\'D\',\'H\',\'B\',\'V\',\'C\',\'V\',\'E\',\'V\'],{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'coords\'][\'A\']==(0,0,3,2) and decode_postfix([\'A\',\'D\',\'H\',\'B\',\'V\',\'C\',\'V\',\'E\',\'V\'],{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'coords\'][\'D\']==(0,2,3,1) and decode_postfix([\'A\',\'D\',\'H\',\'B\',\'V\',\'C\',\'V\',\'E\',\'V\'],{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'coords\'][\'B\']==(3,0,2,3) and decode_postfix([\'A\',\'D\',\'H\',\'B\',\'V\',\'C\',\'V\',\'E\',\'V\'],{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'coords\'][\'C\']==(5,0,2,2) and decode_postfix([\'A\',\'D\',\'H\',\'B\',\'V\',\'C\',\'V\',\'E\',\'V\'],{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'coords\'][\'E\']==(7,0,2,2)',scope))
    print(("PASS" if ok else "FAIL"),'standard coordinates match the taught layout')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'standard coordinates match the taught layout');failed+=1
except Exception as e:
    print("FAIL",'standard coordinates match the taught layout',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: len(r[\'rows\'])==5 and [row[0] for row in r[\'rows\']]==[\'A\',\'B\',\'C\',\'D\',\'E\'] and validate_layout(r[\'rows\'],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'legal\'] is True)(decode_postfix([\'A\',\'D\',\'H\',\'B\',\'V\',\'C\',\'V\',\'E\',\'V\'],{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}))',scope))
    print(("PASS" if ok else "FAIL"),'rows are complete, sorted and checkable')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'rows are complete, sorted and checkable');failed+=1
except Exception as e:
    print("FAIL",'rows are complete, sorted and checkable',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: r[\'tree\'][\'op\']==\'V\' and r[\'tree\'][\'right\'][\'id\']==\'E\' and r[\'tree\'][\'left\'][\'right\'][\'id\']==\'C\' and r[\'tree\'][\'left\'][\'left\'][\'op\']==\'V\' and r[\'tree\'][\'left\'][\'left\'][\'left\'][\'op\']==\'H\' and r[\'tree\'][\'left\'][\'left\'][\'left\'][\'size\']==(3,3))(decode_postfix([\'A\',\'D\',\'H\',\'B\',\'V\',\'C\',\'V\',\'E\',\'V\'],{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}))',scope))
    print(("PASS" if ok else "FAIL"),'tree root and second child')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'tree root and second child');failed+=1
except Exception as e:
    print("FAIL",'tree root and second child',str(e));failed+=1
try:
    ok=bool(eval("decode_postfix(['A','D','H'],{'A':(3,2),'D':(3,1)})['coords']['D']==(0,2,3,1)",scope))
    print(("PASS" if ok else "FAIL"),'popped-first is the second child')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'popped-first is the second child');failed+=1
except Exception as e:
    print("FAIL",'popped-first is the second child',str(e));failed+=1
try:
    ok=bool(eval('decode_postfix([\'D\',\'A\',\'H\',\'B\',\'V\',\'C\',\'V\',\'E\',\'V\'],{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'size\']==(9,3) and decode_postfix([\'D\',\'A\',\'H\',\'B\',\'V\',\'C\',\'V\',\'E\',\'V\'],{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'coords\'][\'A\']==(0,1,3,2) and decode_postfix([\'D\',\'A\',\'H\',\'B\',\'V\',\'C\',\'V\',\'E\',\'V\'],{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'coords\'][\'D\']==(0,0,3,1)',scope))
    print(("PASS" if ok else "FAIL"),'operand swap keeps size but moves coordinates')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'operand swap keeps size but moves coordinates');failed+=1
except Exception as e:
    print("FAIL",'operand swap keeps size but moves coordinates',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: r[\'ok\'] is True and r[\'size\']==(12,3) and validate_layout(r[\'rows\'],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'legal\'] is False)(decode_postfix([\'A\',\'D\',\'V\',\'B\',\'V\',\'C\',\'V\',\'E\',\'V\'],{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}))',scope))
    print(("PASS" if ok else "FAIL"),'first H changed to V overflows to width 12')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'first H changed to V overflows to width 12');failed+=1
except Exception as e:
    print("FAIL",'first H changed to V overflows to width 12',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: r[\'coords\'][\'E\']==(10,0,2,2) and r[\'coords\'][\'B\']==(6,0,2,3))(decode_postfix([\'A\',\'D\',\'V\',\'B\',\'V\',\'C\',\'V\',\'E\',\'V\'],{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}))',scope))
    print(("PASS" if ok else "FAIL"),'overflow row keeps decode-internal consistency')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'overflow row keeps decode-internal consistency');failed+=1
except Exception as e:
    print("FAIL",'overflow row keeps decode-internal consistency',str(e));failed+=1
try:
    ok=bool(eval('decode_postfix([\'A\',\'H\'],{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'ok\'] is False and \'underflow:H\' in decode_postfix([\'A\',\'H\'],{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'errors\']',scope))
    print(("PASS" if ok else "FAIL"),'underflow is reported while reading')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'underflow is reported while reading');failed+=1
except Exception as e:
    print("FAIL",'underflow is reported while reading',str(e));failed+=1
try:
    ok=bool(eval('decode_postfix([\'A\',\'H\'],{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'coords\'] is None and decode_postfix([\'A\',\'H\'],{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'rows\']==[]',scope))
    print(("PASS" if ok else "FAIL"),'underflow keeps partial events but no result')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'underflow keeps partial events but no result');failed+=1
except Exception as e:
    print("FAIL",'underflow keeps partial events but no result',str(e));failed+=1
try:
    ok=bool(eval('\'leftover:2\' in decode_postfix([\'A\',\'D\',\'H\',\'B\',\'V\',\'C\',\'V\',\'E\'],{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'errors\']',scope))
    print(("PASS" if ok else "FAIL"),'leftover regions are reported')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'leftover regions are reported');failed+=1
except Exception as e:
    print("FAIL",'leftover regions are reported',str(e));failed+=1
try:
    ok=bool(eval('\'leftover:5\' in decode_postfix([\'A\',\'B\',\'C\',\'D\',\'E\'],{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'errors\']',scope))
    print(("PASS" if ok else "FAIL"),'leftover regions with a complete set')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'leftover regions with a complete set');failed+=1
except Exception as e:
    print("FAIL",'leftover regions with a complete set',str(e));failed+=1
try:
    ok=bool(eval('\'duplicate:A\' in decode_postfix([\'A\',\'A\',\'H\'],{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'errors\']',scope))
    print(("PASS" if ok else "FAIL"),'duplicate module is rejected')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'duplicate module is rejected');failed+=1
except Exception as e:
    print("FAIL",'duplicate module is rejected',str(e));failed+=1
try:
    ok=bool(eval('\'unknown:F\' in decode_postfix([\'A\',\'F\',\'H\'],{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'errors\']',scope))
    print(("PASS" if ok else "FAIL"),'unknown module is rejected')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'unknown module is rejected');failed+=1
except Exception as e:
    print("FAIL",'unknown module is rejected',str(e));failed+=1
try:
    ok=bool(eval('\'missing:E\' in decode_postfix([\'A\',\'D\',\'H\',\'B\',\'V\',\'C\',\'V\'],{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'errors\']',scope))
    print(("PASS" if ok else "FAIL"),'missing module is rejected')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'missing module is rejected');failed+=1
except Exception as e:
    print("FAIL",'missing module is rejected',str(e));failed+=1
try:
    ok=bool(eval("decode_postfix(['A'],{'A':(3,2)})['ok'] is True and decode_postfix(['A'],{'A':(3,2)})['size']==(3,2)",scope))
    print(("PASS" if ok else "FAIL"),'small catalog single leaf decodes')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'small catalog single leaf decodes');failed+=1
except Exception as e:
    print("FAIL",'small catalog single leaf decodes',str(e));failed+=1
try:
    ok=bool(eval("(lambda r: r['ok'] is True and r['size']==(4,4) and r['coords']['Q']==(0,2,2,2) and r['coords']['R']==(3,0,1,2))(decode_postfix(['P','Q','H','R','V'],{'P':(3,2),'Q':(2,2),'R':(1,2)}))",scope))
    print(("PASS" if ok else "FAIL"),'different catalog decodes independently')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'different catalog decodes independently');failed+=1
except Exception as e:
    print("FAIL",'different catalog decodes independently',str(e));failed+=1
try:
    ok=bool(eval("(lambda r: r['ok'] is True and r['coords']['Q']==(1.5,0,1,2) and r['size']==(2.5,2))(decode_postfix(['P','Q','V'],{'P':(1.5,2),'Q':(1,2)}))",scope))
    print(("PASS" if ok else "FAIL"),'decimal catalog keeps precision')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'decimal catalog keeps precision');failed+=1
except Exception as e:
    print("FAIL",'decimal catalog keeps precision',str(e));failed+=1
try:
    ok=bool(eval("(lambda r: r['size']==(3,5) and r['coords']['E']==(0,3,2,2) and r['coords']['A']==(0,0,3,2) and r['coords']['D']==(0,2,3,1))(decode_postfix(['A','D','H','E','H'],{'A':(3,2),'D':(3,1),'E':(2,2)}))",scope))
    print(("PASS" if ok else "FAIL"),'stacked region lifts the upper child')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'stacked region lifts the upper child');failed+=1
except Exception as e:
    print("FAIL",'stacked region lifts the upper child',str(e));failed+=1
try:
    ok=bool(eval("decode_postfix(['B','A','H'],{'A':(3,2),'B':(2,3)})['size']==(3,5) and decode_postfix(['B','A','H'],{'A':(3,2),'B':(2,3)})['coords']['A']==(0,3,3,2)",scope))
    print(("PASS" if ok else "FAIL"),'B below A stacks heights in the other order')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'B below A stacks heights in the other order');failed+=1
except Exception as e:
    print("FAIL",'B below A stacks heights in the other order',str(e));failed+=1
try:
    ok=bool(eval("(lambda r: r['coords']['P']==(0,0,3,2) and r['coords']['Q']==(3,0,2,2) and r['coords']['R']==(5,0,1,2))(decode_postfix(['P','Q','V','R','V'],{'P':(3,2),'Q':(2,2),'R':(1,2)}))",scope))
    print(("PASS" if ok else "FAIL"),'V children add widths in order')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'V children add widths in order');failed+=1
except Exception as e:
    print("FAIL",'V children add widths in order',str(e));failed+=1
try:
    ok=bool(eval("(lambda r: r['size']==(3,4) and r['coords']['P']==(0,0,3,2) and r['coords']['R']==(0,2,1,2))(decode_postfix(['P','R','H'],{'P':(3,2),'R':(1,2)}))",scope))
    print(("PASS" if ok else "FAIL"),'H children take the max width')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'H children take the max width');failed+=1
except Exception as e:
    print("FAIL",'H children take the max width',str(e));failed+=1
try:
    ok=bool(eval('validate_layout(decode_postfix([\'A\',\'D\',\'H\',\'B\',\'V\',\'C\',\'V\',\'E\',\'V\'],{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'rows\'],(10,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'errors\']==[]',scope))
    print(("PASS" if ok else "FAIL"),'combined rows always pass Lab2 when inside outline')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'combined rows always pass Lab2 when inside outline');failed+=1
except Exception as e:
    print("FAIL",'combined rows always pass Lab2 when inside outline',str(e));failed+=1
try:
    ok=bool(eval('(lambda t: (decode_postfix(t,{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}), t==[\'A\',\'D\',\'H\'])[1])([\'A\',\'D\',\'H\'])',scope))
    print(("PASS" if ok else "FAIL"),'token list is not mutated')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'token list is not mutated');failed+=1
except Exception as e:
    print("FAIL",'token list is not mutated',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: r[\'ok\'] is True and validate_layout(r[\'rows\'],(8,8),{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'legal\'] is False)(decode_postfix([\'A\',\'D\',\'H\',\'B\',\'V\',\'C\',\'V\',\'E\',\'V\'],{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}))',scope))
    print(("PASS" if ok else "FAIL"),'structure and geometry are separate questions')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'structure and geometry are separate questions');failed+=1
except Exception as e:
    print("FAIL",'structure and geometry are separate questions',str(e));failed+=1
try:
    ok=bool(eval('decode_postfix([],{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'ok\'] is False and decode_postfix([],{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]})[\'errors\']',scope))
    print(("PASS" if ok else "FAIL"),'empty token list is an error, not a layout')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'empty token list is an error, not a layout');failed+=1
except Exception as e:
    print("FAIL",'empty token list is an error, not a layout',str(e));failed+=1
try:
    ok=bool(eval('(lambda r: all(0<=v[0] and v[0]+v[2]<=r[\'size\'][0]+1e-9 and 0<=v[1] and v[1]+v[3]<=r[\'size\'][1]+1e-9 for v in r[\'coords\'].values()))(decode_postfix([\'A\',\'D\',\'H\',\'B\',\'V\',\'C\',\'V\',\'E\',\'V\'],{"A":[3,2],"B":[2,3],"C":[2,2],"D":[3,1],"E":[2,2]}))',scope))
    print(("PASS" if ok else "FAIL"),'every coordinate clears its region bounds')
    failed+=not ok
except NotImplementedError:
    print("INCOMPLETE",'every coordinate clears its region bounds');failed+=1
except Exception as e:
    print("FAIL",'every coordinate clears its region bounds',str(e));failed+=1
raise SystemExit(1 if failed else 0)
